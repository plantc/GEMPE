#!/usr/bin/env python3

import pandas as pd
import numpy as np

from collections import defaultdict
import itertools
import json
from sys import argv, exit

def read_adjacency_matrix(f):
    A = defaultdict(int)
    with open(f) as fh:
        n = int(fh.readline().strip())
        fh.readline() # ignore m

        for line in fh.readlines():
            src, dest = list(map(int, line.strip().split(' ')))
            A[(src, dest)] = 1
            A[(dest, src)] = 1

    return (n, A)

def compute_k_most_similar_pairs(embedding, k, use_euclidean_dist=False):
    n = np.shape(embedding)[0]
    dotprods = embedding @ embedding.T

    if use_euclidean_dist:
        sim = -(np.sum(embedding**2, axis=1) + np.sum(embedding**2, axis=1)[:, np.newaxis] - 2*dotprods)
    else:
        sim = dotprods

    sim += np.diag([float("-inf")]*n)

    # use argpartition for partial sorting since n*(n-1)/2 is already pretty large
    indices = sorted([(idx // n, idx % n) for idx in np.argpartition(sim, -k, axis=None)[-k:]], key=lambda t: sim[t], reverse=True)

    return [(t[0], t[1], sim[t]) for t in indices]

graph = 'adjnoun'
n, A = read_adjacency_matrix(f'../../data/{graph}/{graph}.edgelist')
methods = ['GEMPE', 'LINE', 'VERSE', 'deepWalk', 'struc2vec', 'node2vec', 'SDNE', 'AROPE']
mapping = {v: k for k, v in json.load(fp=open(f'../../data/{graph}/{graph}.mapping')).items()}

results = defaultdict(list)
for method in methods:
    print(f"{'='*8} method = {method} {'='*8}")
    try:
        embedding = pd.read_csv(f"../emb/{graph}/{method}_2d_{graph}.emb", sep=" ", header=None).values
    except FileNotFoundError:
        print(f"could not load embedding")
        continue

    pairs = compute_k_most_similar_pairs(embedding, 100, method in ['GEMPE'])

    for i, (a, b, sim) in enumerate(pairs[::2]):
        print(mapping[b], mapping[a])
        results[method].append((i, mapping[a], mapping[b], sim))

with open('similarity_results_adjnoun.json', 'w+') as fh:
    json.dump(results, fp=fh)
