#!/usr/bin/env ruby
# encoding: utf-8

require 'json'

f = ARGV.first
pr = ARGV.size == 2 ? ARGV[1].to_f : 0.3
type = File.extname f

srand 666

g = File.read(f).lines.map { |l| l.split.map &:to_i }
g = g[2..-1] if type == '.edgelist'
g = g.each_slice(2).to_a if type == '.edgelist_directed_weighted'

h = (g.size * pr).floor

hidden = g.sample h
unhidden = g - hidden

renumber = {}
cur = 0
unhidden.map! do |src, dst|
  src, dst, _ = src if type == '.edgelist_directed_weighted'

  if renumber[src].nil? then
    renumber[src] = cur
    cur += 1
  end
  if renumber[dst].nil? then
    renumber[dst] = cur
    cur += 1
  end

  type == '.edgelist_directed_weighted' ? [[renumber[src], renumber[dst], 1], [renumber[dst], renumber[src], 1]] : [renumber[src], renumber[dst]]
end

n_unhidden = cur

hidden.map! do |src, dst|
  src, dst, _ = src if type == '.edgelist_directed_weighted'

  if renumber[src].nil? then
    renumber[src] = cur
    cur += 1
  end
  if renumber[dst].nil? then
    renumber[dst] = cur
    cur += 1
  end

  [renumber[src], renumber[dst]]
end

path_g = File.join File.dirname(f), File.basename(f) + "_graph_hidden_#{(pr*100).to_i}"
path_e = File.join File.dirname(f), File.basename(f) + "_edges_#{(pr*100).to_i}"

if type == '.edgelist_directed_weighted' then
  content = unhidden.map { |l| l.map { |ll| ll.join ' ' }.join "\n" }.join "\n"
else
  content = unhidden.map { |l| l.join ' ' }.join "\n"
end

content = [n_unhidden, unhidden.size].join("\n") + "\n" + content if type == '.edgelist'
File.write path_g, content
puts "wrote to #{path_g}"

File.write path_e, hidden.map { |l| l.join ' ' }.join("\n")
puts "wrote to #{path_e}"

File.write File.join(File.dirname(f), File.basename(f, File.extname(f)) + "_hidden#{pr*100}.mapping"), renumber.to_json
