#!/usr/bin/env python3

import matplotlib.pyplot as plt

import json
from sys import argv
from pathlib import Path

f = argv[1]
thing = argv[2] if len(argv) == 3 else 'precision@k'
results = json.load(open(f))

fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(111)

for key in results.keys():
    x, y = zip(*results[key][thing])
    ax.plot(x, y, label=key)

ax.legend()

ax.set_title(f"link prediction {f}")
ax.set_xlabel("k")
ax.set_ylabel(thing)

ax.grid()

plt.tight_layout()
plt.savefig(f"fig/{Path(f).stem}_{thing}.pdf")
#  plt.show()
