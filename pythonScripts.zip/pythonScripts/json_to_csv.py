#!/usr/bin/env python3

import json
import pandas as pd
from sys import argv, exit
from pathlib import Path

for f in argv[1:]:
    with open(f) as fh:
        r = json.load(fp=fh)

    records = []
    for method in r.keys():
        if isinstance(r[method], list):
            l = len(r[method][0])
            if l == 2:
                for k, score in r[method]:
                    records.append({'method': method, 'k': k, 'precision@k': score})
            elif l == 4:
                for i, a, b, sim in r[method]:
                    records.append({'method': method, 'rank': i, 'similarity': sim, 'word_a': b, 'word_b': a})
            else:
                print("what lenght")
                exit(-1)
        elif isinstance(r[method], dict):
            for thing in r[method].keys():
                for percent, score in r[method][thing]:
                    records.append({'method': method, 'measure': thing, 'percent': percent, 'score': score})
        elif isinstance(r[method], float):
            records.append({'method': method, 'nmi': r[method]})
        else:
            print("what")
            exit(-1)

    pd.DataFrame.from_records(records).to_csv(f"csv/{Path(f).stem}.csv")
