#!/usr/bin/env python3

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score, confusion_matrix

from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier

import numpy as np
import pandas as pd
from sys import exit

import random
from collections import defaultdict
import json

from sklearn.exceptions import UndefinedMetricWarning
import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UndefinedMetricWarning)

methods = ['GEMPE', 'LINE', 'VERSE', 'deepWalk', 'struc2vec', 'node2vec', 'SDNE', 'AROPE']
percentages = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

random.seed(666)
np.random.seed(666)

def read_labels(f):
    labels = []
    with open(f) as fh:
        for line in fh.readlines():
            bits = [0]*39
            for bit in [int(x) for x in line.split(" ")]:
                bits[bit] = 1

            labels.append(bits)

    return np.vstack(labels)

labels = read_labels("../../data/BlogCatalog-dataset/labels.txt")
results = defaultdict(lambda: defaultdict(list))
repeats = 10

for percentage in percentages:
    for method in methods:
        print(f"{'='*8} p = {percentage}, method = {method} {'='*8}")
        embedding = pd.read_csv(f"../emb/blogcatalog/{method}_128d_blogcatalog.emb", sep=" ", header=None).values
        scores = defaultdict(list)

        for _ in range(repeats):
            X_train, X_test, Y_train, Y_test = train_test_split(embedding, labels, train_size=percentage)

            scale = StandardScaler().fit(X_train)
            X_train = scale.transform(X_train)
            X_test = scale.transform(X_test)

            rf = MLPClassifier(max_iter=500).fit(X_train, Y_train)
            Y_pred = rf.predict(X_test)

            f1_macro = f1_score(Y_test, Y_pred, average='macro')
            f1_micro = f1_score(Y_test, Y_pred, average='micro')
            f1_weighted = f1_score(Y_test, Y_pred, average='weighted')
            accuracy = accuracy_score(Y_test, Y_pred)

            scores['f1_macro'].append(f1_macro)
            scores['f1_micro'].append(f1_micro)
            scores['f1_weighted'].append(f1_weighted)
            scores['accuracy'].append(accuracy)

        results[method]['f1_macro'].append((percentage, np.average(scores['f1_macro'])))
        results[method]['f1_micro'].append((percentage, np.average(scores['f1_micro'])))
        results[method]['f1_weighted'].append((percentage, np.average(scores['f1_weighted'])))
        results[method]['accuracy'].append((percentage, np.average(scores['accuracy'])))

        print(f"f1 macro = {results[method]['f1_macro'][-1][-1]}\n" \
              f"f1 micro = {results[method]['f1_micro'][-1][-1]}\n" \
              f"f1 weighted = {results[method]['f1_weighted'][-1][-1]}\n" \
              f"accuracy = {results[method]['accuracy'][-1][-1]}")

with open('results_blogcatalog.json', 'w+') as fh:
    json.dump(results, fp=fh)
