#!/usr/bin/env ruby
# encoding: utf-8

f = File.read(ARGV.first)
n = f.lines[0].to_i
m = f.lines[1].to_i

adjlist = {}
1.upto(n+1) { |i| adjlist[i] = [] }
m_counted = 0

f.lines[2..-1].map { |s| s.split(/\s/).map &:to_i }.each do |src, dest|
  if src == dest then
    puts "self loop #{src} -> #{dest}"
    next
  end

  m_counted += 1
  adjlist[src+1] << dest+1
  adjlist[dest+1] << src+1
end

lines = ["#{n} #{m_counted} 0"] + adjlist.sort_by { |k, _| k }.map { |_, l| l.join(' ') }
File.write File.basename(ARGV.first, File.extname(ARGV.first)) + '.metis', lines.join("\n")
