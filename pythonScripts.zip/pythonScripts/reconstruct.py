#!/usr/bin/env python3

import pandas as pd
import numpy as np

from collections import defaultdict
import itertools
import json
from sys import argv, exit

def read_adjacency_matrix(f):
    A = defaultdict(int)
    with open(f) as fh:
        n = int(fh.readline().strip())
        fh.readline() # ignore m

        for line in fh.readlines():
            src, dest = list(map(int, line.strip().split(' ')))
            A[(src, dest)] = 1
            A[(dest, src)] = 1

    return (n, A)

def compute_k_most_similar_pairs(embedding, k, use_euclidean_dist=False):
    n = np.shape(embedding)[0]
    dotprods = embedding @ embedding.T

    if use_euclidean_dist:
        sim = -(np.sum(embedding**2, axis=1) + np.sum(embedding**2, axis=1)[:, np.newaxis] - 2*dotprods)
    else:
        sim = dotprods

    sim += np.diag([float("-inf")]*n)

    # use argpartition for partial sorting since n*(n-1)/2 is already pretty large
    indices = sorted([(idx // n, idx % n) for idx in np.argpartition(sim, -k, axis=None)[-k:]], key=lambda t: sim[t], reverse=True)

    return [(t[0], t[1], sim[t]) for t in indices]

graph_files = {
    'dblp': '../../data/larger_dblp_data/dblpAdj',
    'cora': '../../data/cora/cora.edgelist',
    'pubmed': '../../data/pubmed/pubmed.edgelist',
    'citeseer': '../../data/citeseer/citeseer.edgelist',
    'blogcatalog': '../../data/BlogCatalog-dataset/edges.edgelist', # this is 0-based!!!
    'youtube': '../../data/YouTube-dataset/youtube.edgelist',
    'emailEuCore': '../../data/emailEuCore/email-Eu-core.edgelist',
    'brazil-airports': '../../data/airports/brazil-airports.edgelist',
    'europe-airports': '../../data/airports/europe-airports.edgelist',
    'usa-airports': '../../data/airports/usa-airports.edgelist'
}

graph = 'blogcatalog' if len(argv) == 1 else argv[1]
n, A = read_adjacency_matrix(graph_files[graph])
methods = ['GEMPE', 'LINE', 'VERSE', 'deepWalk', 'struc2vec', 'node2vec', 'SDNE', 'AROPE']
ks = range(100, 20*n, n // 10)

results = defaultdict(list)
for method in methods:
    embedding = pd.read_csv(f"../emb/{graph}/{method}_128d_{graph}.emb", sep=" ", header=None).values
    pairs = compute_k_most_similar_pairs(embedding, max(ks), method in ["GEMPE"])

    print(f"{'='*8} method = {method} {'='*8}")
    for k in ks:
        s = 0
        for (a, b, _) in pairs[:k]:
            s += A[(a, b)]

        print(f"reconstruction@{k} = {s/k}")
        results[method].append((k, s/k))

with open(f'reconstruct_results_{graph}.json', 'w+') as fh:
    json.dump(results, fp=fh)
