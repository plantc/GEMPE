#!/usr/bin/env python3

import matplotlib.pyplot as plt

import json
from sys import argv
from pathlib import Path

f = argv[1]
results = json.load(open(f))

fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(111)

for key in results.keys():
    x, y = zip(*results[key])
    ax.plot(x, y, label=key)

ax.legend()

ax.set_title(f"network reconstruction {f}")
ax.set_xlabel("k")
ax.set_ylabel("precision@k")

ax.grid()

plt.tight_layout()
#  plt.show()
