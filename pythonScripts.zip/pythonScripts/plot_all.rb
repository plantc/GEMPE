#!/usr/bin/env ruby
# encoding: utf-8

# Dir['json/classify*.json'].each do |f|
  # `python plot_classify_results.py #{f} accuracy`
  # `python plot_classify_results.py #{f} f1_micro`
  # `python plot_classify_results.py #{f} f1_macro`
  # `python plot_classify_results.py #{f} f1_weighted`
# end

# Dir['json/reconstruct*.json'].each do |f|
  # `python plot_reconstruct_results.py #{f}`
# end

Dir['json/link_prediction*.json'].each do |f|
  `python plot_link_predict_results.py #{f} precision@k`
  `python plot_link_predict_results.py #{f} hidden@k`
end

Dir['json/clustering*.json'].each do |f|
  `python plot_clustering_results.py #{f}`
end
