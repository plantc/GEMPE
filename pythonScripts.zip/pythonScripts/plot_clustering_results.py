#!/usr/bin/env python3

import matplotlib.pyplot as plt

import json
from sys import argv
from pathlib import Path

f = argv[1]
results = json.load(open(f))

fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(111)

for key in results.keys():
    nmi = results[key]
    ax.bar(key, nmi, label=key)

ax.set_title(f"clustering_results {f}")
ax.set_xlabel("method")
ax.set_ylabel("NMI")

plt.tight_layout()
plt.savefig(f"fig/{Path(f).stem}.pdf")
#  plt.show()
