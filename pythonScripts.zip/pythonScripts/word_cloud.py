from matplotlib.font_manager import FontProperties
import matplotlib.pyplot as plt
import json
import pandas as pd

graph = 'adjnoun'

f = 100
methods = ['GEMPE', 'LINE', 'VERSE', 'deepWalk', 'struc2vec', 'node2vec', 'AROPE', 'SDNE']
mapping = {v: k for k, v in json.load(fp=open(f'../../data/{graph}/{graph}.mapping')).items()}

for method in methods:
    data = pd.read_csv(f"../emb/{graph}/{method}_2d_{graph}.emb", sep=" ", header=None).values
    plt.subplot(111, facecolor='w')
    y_min, y_max, x_min, x_max = 1000, -1000, 1000, -1000
    for idx, row in enumerate(data):
        x, y = f*float(row[0]), f*float(row[1])
        y_min = min(y, y_min)
        y_max = max(y, y_max)
        x_min = min(x, x_min)
        x_max = max(x, x_max)

        plt.text(x, y, mapping[idx])

    plt.axis([x_min, x_max, y_min, y_max])
    plt.axis('off')
    plt.savefig(f"fig/wordcloud_{graph}_{method}.pdf")
    #  plt.show()
