#!/usr/bin/env python3

import matplotlib.pyplot as plt

import json
from sys import argv
from pathlib import Path

f = argv[1]
what = argv[2] if len(argv) == 3 else None
results = json.load(open(f))

fig = plt.figure(figsize=(10, 6))
ax = fig.add_subplot(111)

for key in results.keys():
    if what is None:
        x, y = zip(*results[key])
    else:
        x, y = zip(*results[key][what])

    ax.plot(x, y, '-o', label=key)

ax.legend()
ax.set_title(f + ' ' + (what if what is not None else ''))
ax.set_xlabel('relative training set size in percent')
ax.set_ylabel((what if what is not None else '???') + ' score averaged over 100 repeats')
ax.grid()

plt.tight_layout()
plt.savefig(f"fig/{Path(f).stem}_{what}.pdf")
#  plt.show()
