#!/usr/bin/env ruby
# encoding: utf-8

f = ARGV.first
s = File.read(f).lines.map(&:split).map { |a, b| [[a, b, 1], [b, a, 1]] }.flatten(1)

File.write File.join(File.dirname(f), File.basename(f, File.extname(f)) + '.edgelist_directed_weighted'), s.map { |l| l.join ' ' }.join("\n")
