#!/usr/bin/env python3

import pandas as pd
import numpy as np

from collections import defaultdict
import itertools
import json
from sys import argv, exit

def read_adjacency_matrix(f):
    A = defaultdict(int)
    with open(f) as fh:
        n = int(fh.readline().strip())
        fh.readline() # ignore m

        for line in fh.readlines():
            src, dest = list(map(int, line.strip().split(' ')))
            A[(src, dest)] = 1
            A[(dest, src)] = 1

    return (n, A)

def read_hidden_matrix(f):
    m = 0
    A = defaultdict(int)
    with open(f) as fh:
        for line in fh.readlines():
            src, dest = list(map(int, line.strip().split(' ')))
            m += 1
            A[(src, dest)] = 1
            A[(dest, src)] = 1

    return (m, A)

def compute_k_most_similar_pairs(embedding, k, use_euclidean_dist=False):
    n = np.shape(embedding)[0]
    dotprods = embedding @ embedding.T

    if use_euclidean_dist:
        sim = -(np.sum(embedding**2, axis=1) + np.sum(embedding**2, axis=1)[:, np.newaxis] - 2*dotprods)
    else:
        sim = dotprods

    sim += np.diag([float("-inf")]*n)

    # use argpartition for partial sorting since n*(n-1)/2 is already pretty large
    indices = sorted([(idx // n, idx % n) for idx in np.argpartition(sim, -k, axis=None)[-k:]], key=lambda t: sim[t], reverse=True)

    return [(t[0], t[1], sim[t]) for t in indices]

graph_files = {
    'dblp': ('../../data/larger_dblp_data/dblp.edgelist', '../../data/larger_dblp_data/dblp.edgelist_edges_30'),
    'blogcatalog': ('../../data/BlogCatalog-dataset/edges.edgelist', '../../data/BlogCatalog-dataset/edges.edgelist_edges_30'),
    'cora': ('../../data/cora/cora.edgelist', '../../data/cora/cora.edgelist_edges_30'),
    'youtube': ('../../data/YouTube-dataset/youtube.edgelist', '../../data/YouTube-dataset/youtube.edgelist_edges_30'),
    'emailEuCore': ('../../data/emailEuCore/email-Eu-core.edgelist', '../../data/emailEuCore/email-Eu-core.edgelist_edges_0.3'),
    'pubmed': ('../../data/pubmed/pubmed.edgelist', '../../data/pubmed/pubmed.edgelist_edges_30')
}

graph = 'emailEuCore' if len(argv) == 1 else argv[1]
p = 30

graph_file, edge_file = graph_files[graph]

n, A = read_adjacency_matrix(graph_file)
m, H = read_hidden_matrix(edge_file)
mapping = {v: int(k) for k, v in json.load(fp=open(f'../../data/{graph}/{graph}_hidden{p}.mapping')).items()}
methods = ['GEMPE', 'LINE', 'VERSE', 'deepWalk', 'struc2vec', 'node2vec', 'SDNE', 'AROPE']
ks = range(100, 20*n, n // 10)

results = defaultdict(lambda: defaultdict(list))
for method in methods:
    embedding = pd.read_csv(f"../emb/{graph}_hidden{p}/{method}_128d_{graph}_hidden{p}.emb", sep=" ", header=None).values
    pairs = compute_k_most_similar_pairs(embedding, max(ks), method in ["GEMPE"])

    print(f"{'='*8} method = {method} {'='*8}")
    for k in ks:
        s = 0
        h = 0
        for (a, b, _) in pairs[:k]:
            s += A[(mapping[a], mapping[b])]
            h += H[(mapping[a], mapping[b])]

        print(f"precision@{k} = {s/k}")
        print(f"hidden@{k} = {h/m}")
        results[method]['precision@k'].append((k, s/k))
        results[method]['hidden@k'].append((k, h/m))

with open(f'link_prediction_results_{graph}.json', 'w+') as fh:
    json.dump(results, fp=fh)
