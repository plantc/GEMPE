#!/usr/bin/env python3

from sklearn.metrics import normalized_mutual_info_score
from sklearn.cluster import KMeans

import random
from collections import defaultdict
import json

import pandas as pd
import numpy as np

import warnings
warnings.filterwarnings("ignore", category=FutureWarning)

methods = ['GEMPE', 'LINE', 'VERSE', 'deepWalk', 'struc2vec', 'node2vec', 'AROPE', 'SDNE']

true_labels = np.ravel(pd.read_csv('../../data/larger_dblp_data/labels.txt', header=None).values)
labels = np.ravel(pd.read_csv('../cluster/dblp_clustering', header=None).values)

results = {}

print(f"{'='*16} graph = DBLP {'='*16}")
print(f"{'='*8} method = VieClus {'='*8}")
nmi = normalized_mutual_info_score(true_labels, labels)
print(f"NMI = {nmi}")
results["VieClus"] = nmi

random.seed(666)
np.random.seed(666)

for method in methods:
    print(f"{'='*8} method = {method} {'='*8}")
    embedding = pd.read_csv(f"../emb/dblp/{method}_128d_dblp.emb", sep=" ", header=None).values
    km = KMeans(n_clusters=np.max(true_labels) + 1).fit(embedding)
    nmi = normalized_mutual_info_score(true_labels, km.labels_)
    results[method] = nmi
    print(f"NMI = {nmi}")

with open('clustering_results_dblp.json', 'w+') as fh:
    json.dump(results, fp=fh)

results = {}

true_labels = np.ravel(pd.read_csv('../../data/larger_dblp_data/labels3.txt', header=None).values)

print(f"{'='*16} graph = DBLP (labels3) {'='*16}")
print(f"{'='*8} method = VieClus {'='*8}")
nmi = normalized_mutual_info_score(true_labels, labels)
print(f"NMI = {nmi}")
results["VieClus"] = nmi

random.seed(666)
np.random.seed(666)

for method in methods:
    print(f"{'='*8} method = {method} {'='*8}")
    embedding = pd.read_csv(f"../emb/dblp/{method}_128d_dblp.emb", sep=" ", header=None).values
    km = KMeans(n_clusters=np.max(true_labels) + 1).fit(embedding)
    nmi = normalized_mutual_info_score(true_labels, km.labels_)
    results[method] = nmi
    print(f"NMI = {nmi}")

with open('clustering_results_dblp_labels3.json', 'w+') as fh:
    json.dump(results, fp=fh)

true_labels = np.ravel(pd.read_csv(f'../../data/emailEuCore/email-Eu-core-department-labels.txt', sep=" ")['label'].values)
labels = np.ravel(pd.read_csv('../cluster/email_clustering', header=None).values)

results = {}

print(f"{'='*16} graph = emailEuCore {'='*16}")
print(f"{'='*8} method = VieClus {'='*8}")
nmi = normalized_mutual_info_score(true_labels, labels)
print(f"NMI = {nmi}")
results["VieClus"] = nmi

for method in methods:
    print(f"{'='*8} method = {method} {'='*8}")
    embedding = pd.read_csv(f"../emb/emailEuCore/{method}_128d_emailEuCore.emb", sep=" ", header=None).values
    km = KMeans(n_clusters=np.max(true_labels) + 1).fit(embedding)
    nmi = normalized_mutual_info_score(true_labels, km.labels_)
    results[method] = nmi
    print(f"NMI = {nmi}")

with open('clustering_results_emailEuCore.json', 'w+') as fh:
    json.dump(results, fp=fh)

true_labels = np.ravel(pd.read_csv(f'../../data/pubmed/pubmed.labels', sep=" ")['label'].values)
labels = np.ravel(pd.read_csv('../cluster/pubmed_clustering', header=None).values)

results = {}

print(f"{'='*16} graph = pubmed {'='*16}")
print(f"{'='*8} method = VieClus {'='*8}")
nmi = normalized_mutual_info_score(true_labels, labels)
print(f"NMI = {nmi}")
results["VieClus"] = nmi

for method in methods:
    print(f"{'='*8} method = {method} {'='*8}")
    embedding = pd.read_csv(f"../emb/pubmed/{method}_128d_pubmed.emb", sep=" ", header=None).values
    km = KMeans(n_clusters=np.max(true_labels)).fit(embedding)
    nmi = normalized_mutual_info_score(true_labels, km.labels_)
    results[method] = nmi
    print(f"NMI = {nmi}")

with open('clustering_results_pubmed.json', 'w+') as fh:
    json.dump(results, fp=fh)
