#!/usr/bin/env ruby
# encoding: utf-8

require 'json'

f = ARGV.first
s = File.read(f).lines.map &:split
renumber = {}
cur = 0

r = s.map do |src, dst|
  if renumber[src].nil? then
    renumber[src] = cur
    cur += 1
  end

  if renumber[dst].nil? then
    renumber[dst] = cur
    cur += 1
  end

  [renumber[src], renumber[dst]]
end

# File.write File.join(File.dirname(f), File.basename(f, File.extname(f)) + '.edgelist'), r.map { |l| l.join ' ' }.join("\n")
File.write File.join(File.dirname(f), File.basename(f, File.extname(f)) + '.mapping'), renumber.to_json
