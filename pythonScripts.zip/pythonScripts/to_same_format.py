#!/usr/bin/env python3

from sys import argv, exit
from pathlib import Path
import numpy as np
import scipy.io as sio

def read_file(fname):
    with open(fname) as f:
        stripped_lines = [[w.strip() for w in line.strip().split(' ')] for line in f.readlines()]
    return stripped_lines

def from_skipgram(fname, header=False):
    with open(fname) as f:
        if header: next(f)
        sorted_lines = sorted(list(map(lambda s: s.strip().split(' '), f.readlines())), key=lambda l: int(l[0]))
        stripped_lines = list(map(lambda x: x[1:], sorted_lines))

    return stripped_lines

def from_binary(fname, dim):
    ary = np.fromfile(fname, np.float32)
    return np.asarray(list(map(str, ary))).reshape(-1, dim)

def from_mat(fname, variable='embedding'):
    embedding = sio.loadmat(fname)[variable]
    dim = np.shape(embedding)[1]
    return np.asarray(list(map(str, np.ravel(embedding)))).reshape(-1, dim)

methods = [
    ('GEMPE', 'goodtogo', None, None),
    ('node2vec', 'binary', None, None),
    ('LINE', 'skipgram', True, None),
    ('deepWalk', 'skipgram', True, None),
    ('VERSE', 'binary', None, None),
    ('struc2vec', 'skipgram', True, None),
    ('SDNE', 'mat', None, 'embedding'),
    ('AROPE', 'mat', None, 'U')
]

if len(argv) < 2:
    print("directory missing")
    exit(-1)

d = argv[1]
dim = 128 if len(argv) < 3 else int(argv[2])
thing = f"{dim}d_{Path(d).stem}"

for (name, fmt, has_header, variable_name) in methods:
    filename = f"{d}/{name}_{thing}{'.bin' if fmt == 'binary' else ''}"
    outfile = f"emb/{Path(d).stem}/{name}_{thing}.emb"
    Path(f"emb/{Path(d).stem}").mkdir(parents=True, exist_ok=True)

    try:
        lines = None
        if fmt == 'goodtogo':
            lines = read_file(filename)
        elif fmt == 'skipgram':
            lines = from_skipgram(filename, has_header)
        elif fmt == 'binary':
            lines = from_binary(filename, dim)
        elif fmt == 'mat':
            lines = from_mat(filename, variable_name)
        else:
            print("unknown format")
            exit(-1)

        with open(outfile, 'w+') as out:
            for line in lines: out.write(' '.join(line) + '\n')
    except:
        print(f"could not load {filename}")
