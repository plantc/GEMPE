Most of the experimental data are available at the University of Florida Sprarse Matrix Collection. As our implementation requests the data in full Matlab matrix format, we also provide them here.

Filename, variablename:

Uniformly distributed synthetic data in Fig. 1
"epsilonGraphs.mat", "epsilonGraph_02"

Two Moons data:
"twoMoons.mat", "g6"

Football:
"football.mat", "graph"
Labels: "football.mat", "labels"

Books:
"polbooks.mat", "graph"
Labels: "polbooks.mat", "labels"

Airflights:
"airflights.mat", "graph"
Labels: labels_airflights.mat

Small finite element mesh
"meshes.mat", "eppstein"

Larger finite element mesh
"meshes.mat", "tapir"

Roadmap
"minnesotaL.mat", "graph"

DBLP
"dblp.mat", "graph"
Labels: "labelsDblp.mat", "labels"


