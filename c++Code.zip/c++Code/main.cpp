/* 
 * File:   main.cpp
 *
 * Created on 22. Mai 2018, 14:24
 */

using namespace std;
void *__gxx_personality_v0;

#ifndef NUM_THREADS
#define NUM_THREADS 1
#endif

typedef double vec __attribute__((vector_size(64), aligned(64)));
typedef double vec4 __attribute__((vector_size(32), aligned(32)));
typedef double vecu __attribute__((vector_size(64)));
typedef long long veci64 __attribute__((vector_size(64), aligned(64)));

#include <omp.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <immintrin.h>
#include <x86intrin.h>
#include <math.h>
// #include "hilloop.h"

#define DBL_MAX         1.7976931348623158e+308

//#include <cstdlib>

double * mallocA64(size_t s) {
    long long adr = (long long) malloc(s + 72);
    long long adr2 = (adr + 71) & ~63;
    ((long long *) adr2)[-1] = adr;
    return (double *) adr2;
}

double * callocA64(size_t s) {
    long long adr = (long long) calloc(s + 72, 1);
    long long adr2 = (adr + 71) & ~63;
    ((long long *) adr2)[-1] = adr;
    return (double *) adr2;
}

void freeA64(void * adr) {
    free((void *) (((long long *) adr)[-1]));
}

double stopc(void) {
    static double last;
    double c = clock();
    double r = c - last;
    last = c;
    return r / CLOCKS_PER_SEC;
}

double stop(void) {
    static struct timeval last;
    struct timeval c;
    gettimeofday(&c, NULL);
    double r = (double) (c.tv_sec - last.tv_sec) + (double) (c.tv_usec - last.tv_usec) / 1000000.;
    last.tv_sec = c.tv_sec;
    last.tv_usec = c.tv_usec;
    return r;
}

double timestamp(void) {
    struct timeval c;
    gettimeofday(&c, NULL);
    int r = (c.tv_sec * 1000 + c.tv_usec / 1000) % 1000000;
    return (double) r / 1000.;
}

inline void printvec(__m512 x) {
    float farr[16];
    _mm512_storeu_ps(farr, x);
    printf("%f %f %f %f \n%f %f %f %f \n%f %f %f %f \n%f %f %f %f \n\n",
            farr[0], farr[1], farr[2], farr[3], farr[4], farr[5], farr[6], farr[7],
            farr[8], farr[9], farr[10], farr[11], farr[12], farr[13], farr[14], farr[15]);
}

inline void printveci(__m512i x) {
    int farr[16];
    _mm512_storeu_si512(farr, x);
    printf("%3d %3d %3d %3d \n%3d %3d %3d %3d \n%3d %3d %3d %3d \n%3d %3d %3d %3d \n\n",
            farr[0], farr[1], farr[2], farr[3], farr[4], farr[5], farr[6], farr[7],
            farr[8], farr[9], farr[10], farr[11], farr[12], farr[13], farr[14], farr[15]);
}

//inline __m512 _cb512_exp_ps (__m512 x){
//    // Pade approximation
//    __m512 numerator = _mm512_set1_ps(1.f) ;
//    __m512 denominator = numerator ;
//    __m512 power = x / _mm512_set1_ps(2.f);
//    numerator += power ;
//    denominator -= power ;
//    power *= x/_mm512_set1_ps(4.f) ;
//    numerator += power ;
//    denominator += power ;
//    power *= x/_mm512_set1_ps(3.f) ;
//    numerator += power ;
//    denominator -= power ;
//    power *= x/_mm512_set1_ps(8.f) ;
//    numerator += power ;
//    denominator += power ;
//    power *= x/_mm512_set1_ps(10.f) ;
//    numerator += power ;
//    denominator -= power ;
//    return _mm512_div_ps(numerator, denominator) ;
//}

inline __m512 _cb512_exp_ps(__m512 x) {
//    __m512 result = _mm512_set1_ps(-256.f);
//    __mmask16 msk = _mm512_cmp_ps_mask(result, x, _CMP_LE_OS);
//    result = _mm512_mask_sub_ps(_mm512_setzero_ps(), msk, _mm512_set1_ps(1.f), x / result);
    __m512 result = _mm512_set1_ps(1.f) + x / _mm512_set1_ps(256.f) ;
    result = _mm512_max_ps(_mm512_setzero_ps(), result) ;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
//    result = _mm512_mask_mul_ps(_mm512_setzero_ps(), msk, result, result);
    return result;
}

inline __m512 _cb512_erf_ps(__m512 y) {
    // Numerical Recipies
    __m512 ones = _mm512_set1_ps(1.f);
    __m512i signvector = _mm512_set1_epi32(2147483648);
    __m512 signum = _mm512_castsi512_ps(_mm512_or_epi32(_mm512_castps_si512(ones),
            _mm512_and_epi32(_mm512_castps_si512(y), signvector)));
    //    _mm512_storeu_ps(farr, _mm512_castsi512_ps(_mm512_andnot_epi32(signvector, _mm512_castps_si512(y))));
    //    printf("%f %f %f %f \n%f %f %f %f \n%f %f %f %f \n%f %f %f %f \n\n",
    //            farr[0], farr[1], farr[2], farr[3], farr[4], farr[5], farr[6], farr[7],
    //            farr[8], farr[9], farr[10], farr[11], farr[12], farr[13], farr[14], farr[15]);
    //    __m512 t = ones / (ones + _mm512_castsi512_ps(_mm512_andnot_epi32(signvector, _mm512_castps_si512(y))) * _mm512_set1_ps(0.5f));
    __m512 yy = _mm512_castsi512_ps(_mm512_andnot_epi32(signvector, _mm512_castps_si512(y)));
    yy = _mm512_min_ps(yy, _mm512_set1_ps(5.f));
    __m512 t = ones / (ones + yy * _mm512_set1_ps(0.5f));
    //    _mm512_storeu_ps(farr, t);
    //    printf("%f %f %f %f \n%f %f %f %f \n%f %f %f %f \n%f %f %f %f \n\n",
    //            farr[0], farr[1], farr[2], farr[3], farr[4], farr[5], farr[6], farr[7],
    //            farr[8], farr[9], farr[10], farr[11], farr[12], farr[13], farr[14], farr[15]);
    __m512 power = t;
    __m512 x = power * _mm512_set1_ps(1.00002368f) - _mm512_set1_ps(1.26551223f) - yy*yy;
    power *= t;
    x += power * _mm512_set1_ps(0.37409196f);
    power *= t;
    x += power * _mm512_set1_ps(0.09678418f);
    power *= t;
    x -= power * _mm512_set1_ps(0.18628806f);
    power *= t;
    x += power * _mm512_set1_ps(0.27886807f);
    power *= t;
    x -= power * _mm512_set1_ps(1.13520398f);
    power *= t;
    x += power * _mm512_set1_ps(1.48851587f);
    power *= t;
    x -= power * _mm512_set1_ps(0.82215223f);
    power *= t;
    x += power * _mm512_set1_ps(0.17087277f);
    __m512 result = _mm512_set1_ps(1.f) + x / _mm512_set1_ps(256.f);
    result = _mm512_max_ps(_mm512_setzero_ps(), result) ;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result *= result;
    result = signum * (ones - t * result);
    // TEST TEST TEST
//    float yarr[16], rarr[16];
//    _mm512_storeu_ps(yarr, y);
//    _mm512_storeu_ps(rarr, result);
//    for(int i=0 ; i<16 ; i++){
//        if(abs((rarr[i]-erf(yarr[i]))/erf(yarr[i]))>0.1)
//            printf("%9.6f %9.6f %9.6f   %4.1f\n", yarr[i], erf(yarr[i]), rarr[i], abs((rarr[i]-erf(yarr[i]))/erf(yarr[i]))*100.);
//        if(drand48()<1e-6)
//            printf("\t\t\t\t%9.6f %9.6f %9.6f   %4.1f\n", yarr[i], erf(yarr[i]), rarr[i], abs((rarr[i]-erf(yarr[i]))/erf(yarr[i]))*100.);
//    }
//
//    for(int i=0 ; i<16 ; i++)
//        yarr[i]=erf(yarr[i]);
//    result = _mm512_loadu_ps(yarr);
    return result;
}

void parabolaEdge(__m512 x, float mu, float sigma) {
    __m512 is2spil2 = _mm512_set1_ps(0.5755520493);
    __m512 minvalue = _mm512_set1_ps(1e-6f);
    //    float sq2ipi = 0.7978845605;
    //    float isq2 = 0.7071067814;
    __m512 SIGMA = _mm512_set1_ps(sigma);
    __m512 h = (x - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562 * sigma);
    __m512 EXP = _cb512_exp_ps(-h * h);
    __m512 ERF = _mm512_min_ps(_mm512_setzero_ps() - minvalue, _cb512_erf_ps(h) - _mm512_set1_ps(1.f));
    __m512 w = ((is2spil2 * x - _mm512_set1_ps(0.8633280737)) / SIGMA
            + _mm512_set1_ps(0.4592240941) * EXP / ERF)
            * EXP / (SIGMA * SIGMA * ERF);
    //    w = _mm512_max_ps(w, minvalue);
    //    w = _mm512_max_ps(w, _mm512_setzero_ps());
    //    __mmask16 k = _mm512_cmplt_ps_mask(w, _mm512_setzero_ps());
    __mmask16 k = _mm512_cmpge_epi32_mask(_mm512_castps_si512(w), _mm512_setzero_epi32());
    k = _mm512_kand(k, _mm512_cmpneq_epi32_mask(_mm512_castps_si512(w), _mm512_set1_epi32(0x7F800000)));
    printf("%x\n", k);
    __m512 d = is2spil2 * EXP / w / SIGMA / ERF;
    d = _mm512_castsi512_ps(_mm512_maskz_or_epi32(k, _mm512_castps_si512(d), _mm512_castps_si512(d)));
    w = _mm512_castsi512_ps(_mm512_maskz_or_epi32(k, _mm512_castps_si512(w), _mm512_castps_si512(w)));
    d += x;
    printvec(d);
    printvec(w);
}

void parabolaNoEdge(__m512 x, float mu, float sigma) {
    __m512 is2spil2 = _mm512_set1_ps(0.5755520493);
    __m512 minvalue = _mm512_set1_ps(1e-6f);
    //    float sq2ipi = 0.7978845605;
    //    float isq2 = 0.7071067814;
    __m512 SIGMA = _mm512_set1_ps(sigma);
    __m512 h = (x - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562 * sigma);
    __m512 EXP = _cb512_exp_ps(-h * h);
    __m512 ERF = _mm512_max_ps(minvalue, _cb512_erf_ps(h) + _mm512_set1_ps(1.f));
    __m512 w = ((is2spil2 * x - _mm512_set1_ps(0.8633280737)) / SIGMA
            + _mm512_set1_ps(0.4592240941) * EXP / ERF)
            * EXP / (SIGMA * SIGMA * ERF);
    w = _mm512_max_ps(w, minvalue);
    __mmask16 k = _mm512_cmpge_epi32_mask(_mm512_castps_si512(w), _mm512_setzero_epi32());
    k = _mm512_kand(k, _mm512_cmpneq_epi32_mask(_mm512_castps_si512(w), _mm512_set1_epi32(0x7F800000)));
    printf("%x\n", k);
    __m512 d = is2spil2 * EXP / w / SIGMA / ERF;
    d = _mm512_castsi512_ps(_mm512_maskz_or_epi32(k, _mm512_castps_si512(d), _mm512_castps_si512(d)));
    w = _mm512_castsi512_ps(_mm512_maskz_or_epi32(k, _mm512_castps_si512(w), _mm512_castps_si512(w)));
    d += x;
    printvec(d);
    printvec(w);
}

float *denomverta, *denome12, *denome13, *denome24, *nomv1, *nomv2, *nomv3, *nomv4, *nomold3, *nomold4;
float * nom_coord;
int *oldpartners3, *oldpartners4;
int n, d, m; 
float *v; 
int *first, *second; 
char *hash; 
float mu, sigma;
int hashsize;
int initrand;
int *histop, *histom;
int *sortfield;
float EGO_epsilon;
int * scramble;

void initmem(int nn, int mm, float mmu, float ssigma) {
    n=nn; m=mm; mu=mmu; sigma=ssigma;
    hashsize = m;
    hashsize |= hashsize>>1;
    hashsize |= hashsize>>2;
    hashsize |= hashsize>>4;
    hashsize |= hashsize>>8;
    hashsize |= hashsize>>16;
    hashsize += 1;
    hashsize *= 256 ;
    mm = (m+15)/16*16 ;
    v = (float *) malloc ((n+2)*d*sizeof(float));
    denomverta = (float *) calloc ((n+2),sizeof(float));
    denome12 = (float *) calloc (mm,sizeof(float));
    denome13 = (float *) calloc (mm,sizeof(float));
    denome24 = (float *) calloc (mm,sizeof(float));
    nomv1 = (float *) calloc (mm*d,sizeof(float));
    nomv2 = (float *) calloc (mm*d,sizeof(float));
    nomv3 = (float *) calloc (mm*d,sizeof(float));
    nomv4 = (float *) calloc (mm*d,sizeof(float));
    nomold3 = (float *) calloc (mm*d,sizeof(float));
    nomold4 = (float *) calloc (mm*d,sizeof(float));
    oldpartners3 = (int *) calloc (mm,sizeof(int));
    oldpartners4 = (int *) calloc (mm,sizeof(int));
    hash = (char *) calloc (hashsize, 1);
    first = (int *) malloc(mm*sizeof(int));
    second = (int *) malloc(mm*sizeof(int));
    initrand = 1234;
    histop = (int *) malloc(256*sizeof(int));
    histom = (int *) malloc(256*sizeof(int));
    sortfield = (int *) malloc(n*sizeof(int));
    for (int i=0 ; i<n ; i++)
        sortfield[i] = i;
    EGO_epsilon = 1.f;
}

#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif
#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#endif

float quot(float x) {
    float a[] = {0.f, 3.643839659e-14f, 8.025775889e-10f, 0.000002391756971f, 0.0009630309489f, 0.05264270870f, 0.3487847716f, 0.2833288512f, 0.1047041485f, 0.04062593758f, 0.02871404198f, -0.01346640946f, -0.01244761323f, -0.04119400318f, 0.f, 0.f};
    float b[] = {0.f, 4.736991556e-13f, 8.82835347e-9f, 0.00002152581274f, 0.006741216642f, 0.2632135435f, 1.165507311f, 1.100051390f, 1.278676093f, 1.470910726f, 1.530470204f, 1.825733364f, 1.816564198f, 2.132774487f, 1.79975605f, 1.772453851f};
    float c[] = {0.f, 1.539522256e-12f, 2.427800850e-8f, 0.00004843388127f, 0.01179952168f, 0.3299823529f, 1.016363980f, 1.0f, 0.9553438243f, 0.8111678497f, 0.7367185022f, 0.2200079720f, 0.2406385956f, -0.6289396998f, -0.20476649f, 0.f};
    int idx = (int) max(0, min(7.5f, x) + 7.5f);
    return (a[idx] * x + b[idx])*x + c[idx];
}

float sigmaFromHist(void){
    // ONLY CORRECT IF histom and histop contain iid samples of the distances
    float upper = 20.f;
    float lower = 0.f;
    int countm=0;
    int countp=0;
    for(int i=0; i<256 ; i++)
        countm += histom[i];
    for(int i=0; i<256 ; i++)
        countp += histop[i];
    float factorm = ((float) n * ((float) n - 1.f)*.5f - (float) m) / (float) countm * (float) countp / (float) m;
    float sig;
    for (int i = 0; i < 20; i++) {
        sig = (upper + lower) / 2.;
        float sum = 0;
        for(int j=0 ; j<256 ; j++){
            float J = ((float) j + .5f) / 7.5f;
            sum += (J-mu) * ((float)(histop[j])*quot((J-mu)*0.7071067f/sig) - factorm*(float)(histom[j])*quot((mu-J)*0.7071067f/sig));
        }
        if (sum < 0) {
            upper = sig;
        } else {
            lower = sig;
        }
    }
    return sig;
}

double costFromHist(void) {
    // ONLY CORRECT IF histom and histop contain iid samples of the distances
    long long countm = 0;
    long long countp = 0;
    for (int i = 0; i < 256; i++)
        countm += histom[i];
    for (int i = 0; i < 256; i++)
        countp += histop[i];
    double factorp = (double) m / (double) countp;
    double factorm = ((double) n * ((double) n - 1.)*.5 - (double) m) / (double) countm;
    double cost = 0;
    for (int j = 0; j < 256; j++) {
        double h = erf((((double) j + .5) / 7.5 - mu) * 0.7071067 / sigma);
//        printf("%d %f %f %f %f\n", j, h, log(.5f - .5f * h), log(.5f + .5f * h), cost);
        if(histop[j])
            cost -= factorp * histop[j] * log(.5 - .5 * h);
        if(histom[j])
            cost -= factorm * histom[j] * log(.5 + .5 * h);
    }
    return cost / log(2.);
}

void printHist(void) {
    // ONLY CORRECT IF histom and histop contain iid samples of the distances
    long long countm = 0;
    long long countp = 0;
    for (int i = 0; i < 256; i++)
        countm += histom[i];
    for (int i = 0; i < 256; i++)
        countp += histop[i];
    double factorp = (double) m / (double) countp;
    double factorm = ((double) n * ((double) n - 1.)*.5 - (double) m) / (double) countm;
    double cost = 0;
    for (int j = 0; j < 256; j++) {
        double h = ((double) j + .5) / 7.5;
        printf("%f %f %f %f %f\n", h, factorp * histop[j], factorm * histom[j], factorp * histop[j]/(factorp * histop[j] + factorm * histom[j]), .5 - .5 * erf((h-mu)* 0.7071067 / sigma));
    }
}

void parabola(float x, int isEdge, float *d, float *w) {
    const double is2spil2 = 0.5755520493f;
    const double isq2 = 0.7071067f;
    double h = (x - mu) * isq2 / sigma;
    double quot;
    if (isEdge) {
        if (h < 2.44459) {
            double EXP = exp(-h * h);
            double ERF = erf(h);
            ERF -= 1.;
            ERF = min(ERF, -1e-20);
            quot = EXP / ERF;
        } else {
            quot = -h * 1.772453851;
        }
    } else {
        if (h > -2.44459) {
            double EXP = exp(-h * h);
            double ERF = erf(h);
            ERF += 1.;
            ERF = max(ERF, 1e-20);
            quot = EXP / ERF;
        } else {
            quot = h * (-1.772453851);
        }
    }

    *w = (float)(((is2spil2 * x - 0.8633280737) / sigma
            + 2 * 0.4592240941 * quot)
            * quot / sigma / sigma);
    *w = max(*w, 0);
    //        w = min(w, maxWeight) ;
    //        w = max(w, minWeight) ;
    *d = x;
    if (*w != 0) {
        *d += (float)(is2spil2 * quot / *w / sigma);
    } // else {
//        *d = 0;
//    }
    //        if (d < 0 || w < 0) {
    //            d = 0;
    //            w = -is2spil2 * EXP / sigma / x / ERF;
    //            w = min(w, maxWeight) ;
    //        }
}

__m512 quotp(__m512 x) {
    float a[] = {0.f, 3.643839659e-14f, 8.025775889e-10f, 0.000002391756971f, 0.0009630309489f, 0.05264270870f, 0.3487847716f, 0.2833288512f, 0.1047041485f, 0.04062593758f, 0.02871404198f, -0.01346640946f, -0.01244761323f, -0.04119400318f, 0.f, 0.f};
    float b[] = {0.f, 4.736991556e-13f, 8.82835347e-9f, 0.00002152581274f, 0.006741216642f, 0.2632135435f, 1.165507311f, 1.100051390f, 1.278676093f, 1.470910726f, 1.530470204f, 1.825733364f, 1.816564198f, 2.132774487f, 1.79975605f, 1.772453851f};
    float c[] = {0.f, 1.539522256e-12f, 2.427800850e-8f, 0.00004843388127f, 0.01179952168f, 0.3299823529f, 1.016363980f, 1.0f, 0.9553438243f, 0.8111678497f, 0.7367185022f, 0.2200079720f, 0.2406385956f, -0.6289396998f, -0.20476649f, 0.f};
    __m512 A = _mm512_loadu_ps(a);
    __m512 B = _mm512_loadu_ps(b);
    __m512 C = _mm512_loadu_ps(c);
    __m512 c75 = _mm512_set1_ps(7.5f);
    __m512 c0 = _mm512_setzero_ps();
    //__m512i idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(_mm512_setzero_ps(), x+_mm512_set1_ps(7.5)), _MM_FROUND_TO_ZERO |_MM_FROUND_NO_EXC);
    //idx = _mm512_min_epi32(idx, _mm512_set1_epi32(15));
    __m512i idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, x) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
    return (_mm512_permutexvar_ps(idx, A) * x + _mm512_permutexvar_ps(idx, B))*x + _mm512_permutexvar_ps(idx, C);
}

__m512 quotm(__m512 x) {
    float a[] = {0.f, 3.643839659e-14f, 8.025775889e-10f, 0.000002391756971f, 0.0009630309489f, 0.05264270870f, 0.3487847716f, 0.2833288512f, 0.1047041485f, 0.04062593758f, 0.02871404198f, -0.01346640946f, -0.01244761323f, -0.04119400318f, 0.f, 0.f};
    float b[] = {0.f, 4.736991556e-13f, 8.82835347e-9f, 0.00002152581274f, 0.006741216642f, 0.2632135435f, 1.165507311f, 1.100051390f, 1.278676093f, 1.470910726f, 1.530470204f, 1.825733364f, 1.816564198f, 2.132774487f, 1.79975605f, 1.772453851f};
    float c[] = {0.f, 1.539522256e-12f, 2.427800850e-8f, 0.00004843388127f, 0.01179952168f, 0.3299823529f, 1.016363980f, 1.0f, 0.9553438243f, 0.8111678497f, 0.7367185022f, 0.2200079720f, 0.2406385956f, -0.6289396998f, -0.20476649f, 0.f};
    __m512 A = _mm512_loadu_ps(a);
    __m512 B = _mm512_loadu_ps(b);
    __m512 C = _mm512_loadu_ps(c);
    __m512 c75 = _mm512_set1_ps(7.5f);
    __m512 c0 = _mm512_setzero_ps();
    // __m512i idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(_mm512_setzero_ps(), _mm512_set1_ps(7.5)-x), _MM_FROUND_TO_ZERO |_MM_FROUND_NO_EXC);
    // idx = _mm512_min_epi32(idx, _mm512_set1_epi32(15));
    __m512i idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, c0 - x) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
    return (_mm512_permutexvar_ps(idx, A) * x - _mm512_permutexvar_ps(idx, B))*x + _mm512_permutexvar_ps(idx, C);
}

void firstIter(int num_rounds) {
    nom_coord = (float*) malloc((n+2) * d * sizeof (float));

    int row[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    for (int round = 0; round < num_rounds; round++) {
        initrand += 1024;
        memset(denomverta, 0, n*sizeof(float));
        memset(nom_coord, 0, n*d*sizeof(float));
        memset(histop, 0, 256*sizeof(int));
        memset(histom, 0, 256*sizeof(int));
        
#pragma omp parallel for reduction(+:nom_coord[:(n+2)*d]), reduction(+:denomverta[:(n+2)])
        for (int par = 0; par < NUM_THREADS; par++) {
            __m512i randstat = _mm512_loadu_si512(row) + _mm512_set1_epi32(par * 16 + initrand);
            __m512 nnn = _mm512_set1_ps((float) n);
            __m512 mmm = _mm512_set1_ps((float) m);
            __m512i ones = _mm512_set1_epi32(1);
            __m512i largeprime = _mm512_set1_epi32(1103515245);
            __m512i nn = _mm512_set1_epi32(n);
            __m512i hashmask = _mm512_set1_epi32(hashsize-1);
//            for (int i = par * m / 16 / NUM_THREADS * 16; i < (par + 1) * m / 16 / NUM_THREADS * 16 + (par == NUM_THREADS - 1 ? m % 16 : 0); i += 16) {
            for (int i = par * m / 16 / NUM_THREADS * 16; i < (par + 1) * m / 16 / NUM_THREADS * 16 ; i += 16) {
//                randstat = randstat * largeprime + ones;
//                __m512i edges = _mm512_cvt_roundps_epi32(_mm512_castsi512_ps(
//                        _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
//                        _mm512_set1_epi32(0x3f800000))) * mmm - mmm, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                __m512i edges = _mm512_set1_epi32(i) + _mm512_loadu_si512(row);
                __m512i verti1 = _mm512_i32gather_epi32(edges, first, 4);
                __m512i verti2 = _mm512_i32gather_epi32(edges, second, 4);
                __m512i verti3 = _mm512_setzero_epi32();
                __m512i verti4 = _mm512_setzero_epi32();
                __mmask16 msk = 0xffff;
                while (msk) {
                    randstat = randstat * largeprime + ones;
                    verti3 = _mm512_mask_cvt_roundps_epi32(verti3, msk, _mm512_castsi512_ps(
                            _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                            _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
                            _mm512_i32gather_epi32(((verti1 * n + verti3) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                }
                msk = 0xffff;
                while (msk) {
                    randstat = randstat * largeprime + ones;
                    verti4 = _mm512_mask_cvt_roundps_epi32(verti4, msk, _mm512_castsi512_ps(
                            _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                            _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
                            _mm512_i32gather_epi32(((verti2 * n + verti4) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                }
                __m512 dist12 = _mm512_setzero_ps();
                for (int j = 0; j < d; j++) {
                    __m512 h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti2, v + j*n, 4);
                    dist12 += h*h;
                }
                dist12 = _mm512_sqrt_ps(dist12);

                // parabolaEdge
                __m512 h = (dist12 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562f * sigma);
                __m512 EXP = _cb512_exp_ps(-h * h);
                EXP /= _mm512_max_ps(_mm512_set1_ps(1e-20f), _mm512_set1_ps(1.f) - _cb512_erf_ps(h)) ;
                msk = _mm512_cmp_ps_mask(h, _mm512_set1_ps(2.44459f), _CMP_GT_OS);
                EXP = _mm512_mask_mul_ps(EXP, msk, h, _mm512_set1_ps(1.772453851f));
                __m512 w12 = EXP / _mm512_set1_ps(sigma * sigma) * (_mm512_set1_ps(0.9184481882f) * EXP - _mm512_set1_ps(0.8139535142f) * h);
                msk = _mm512_cmp_ps_mask(w12, _mm512_setzero_ps(), _CMP_GT_OS);
                w12 = _mm512_max_ps(w12, _mm512_setzero_ps());
                __m512 d12 = _mm512_mask_sub_ps(dist12, msk, dist12, _mm512_set1_ps(0.5755520493f/sigma) * EXP / w12);
//END NEU
// TEST TEST TEST
//                float hharr[16], harr[16], darr[16], warr[16], exparr[16];
//                _mm512_storeu_ps(hharr, h);
//                _mm512_storeu_ps(harr, dist12);
//                _mm512_storeu_ps(darr, d12);
//                _mm512_storeu_ps(warr, w12);
//                _mm512_storeu_ps(exparr, EXP);
//                for(int j=0 ; j<16 ; j++){
//                    float ddd,www ;
//                    parabola(harr[j], 1, &ddd, &www);
////if(harr[j]<3)
//                    if(www>1e-10 &&(abs((ddd-darr[j]))>0.1 || abs((www-warr[j])/www)>0.1))
//                        printf("++ %f %f %f %f %f %f %f %f\n", hharr[j], harr[j], darr[j], ddd, warr[j], www, abs((ddd-darr[j])), abs((www-warr[j])/www));
//                    if(drand48()<1.e-2 || warr[j]<0)
//                        printf("\t\t++ %f %f %f %f %f %f %f %f     %f %d %x\n", hharr[j], harr[j], darr[j], ddd, warr[j], www, abs((ddd-darr[j])), abs((www-warr[j])/www), exparr[j], j, msk);
//                }
// END TEST
                msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist12), _mm512_setzero_epi32());
                dist12 = _mm512_mask_div_ps(dist12, msk, d12, dist12);
                // this is actually sij
//if(!i)printvec(dist12);
                __m512 dist13 = _mm512_setzero_ps();
                for (int j = 0; j < d; j++) {
                    __m512 h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti3, v + j*n, 4);
                    dist13 += h*h;
                }
                dist13 = _mm512_sqrt_ps(dist13);
                //parabolaNoEdge
                h = (dist13 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562f * sigma);
                EXP = _cb512_exp_ps(-h * h);
                EXP /= _mm512_max_ps(_mm512_set1_ps(1e-20f), _mm512_set1_ps(1.f) + _cb512_erf_ps(h)) ;
                msk = _mm512_cmp_ps_mask(h, _mm512_set1_ps(-2.44459f), _CMP_LT_OS);
                EXP = _mm512_mask_mul_ps(EXP, msk, h, _mm512_set1_ps(-1.772453851f));
                __m512 w13 = EXP / _mm512_set1_ps(sigma * sigma) * (_mm512_set1_ps(0.9184481882f) * EXP + _mm512_set1_ps(0.8139535142f) * h);
                msk = _mm512_cmp_ps_mask(w13, _mm512_setzero_ps(), _CMP_GT_OS);
                w13 = _mm512_max_ps(w13, _mm512_setzero_ps());
                __m512 d13 = _mm512_mask_add_ps(dist13, msk, dist13, _mm512_set1_ps(0.5755520493f/sigma) * EXP / w13);
// TEST TEST TEST
//                _mm512_storeu_ps(hharr, h);
//                _mm512_storeu_ps(harr, dist13);
//                _mm512_storeu_ps(darr, d13);
//                _mm512_storeu_ps(warr, w13);
//                for(int j=0 ; j<16 ; j++){
//                    float ddd,www ;
//                    parabola(harr[j], 0, &ddd, &www);
////if(harr[j]<3)
//                    if(www>1e-10 &&(abs((ddd-darr[j]))>0.1 || abs((www-warr[j])/www)>0.1))
//                        printf("-- %f %f %f %f %f %f %f %f\n", hharr[j], harr[j], darr[j], ddd, warr[j], www, abs((ddd-darr[j])), abs((www-warr[j])/www));
//                    if(drand48()<1.e-2 || warr[j]<0)
//                        printf("\t\t-- 13 %f %f %f %f %f %f %f\n", harr[j], darr[j], ddd, warr[j], www, abs((ddd-darr[j])), abs((www-warr[j])/www));
//                }
// END TEST
 //               if(!i) printvec(dist13);
                msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist13), _mm512_setzero_epi32());
                dist13 = _mm512_mask_div_ps(dist13, msk, d13, dist13);
//if(!i) printvec(dist13);                
                __m512 dist24 = _mm512_setzero_ps();
                for (int j = 0; j < d; j++) {
                    __m512 h = _mm512_i32gather_ps(verti2, v + j*n, 4) - _mm512_i32gather_ps(verti4, v + j*n, 4);
                    dist24 += h*h;
                }
                dist24 = _mm512_sqrt_ps(dist24);
                //parabolaNoEdge
                h = (dist24 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562f * sigma);
                EXP = _cb512_exp_ps(-h * h);
                EXP /= _mm512_max_ps(_mm512_set1_ps(1e-20f), _mm512_set1_ps(1.f) + _cb512_erf_ps(h)) ;
                msk = _mm512_cmp_ps_mask(h, _mm512_set1_ps(-2.44459f), _CMP_LT_OS);
                EXP = _mm512_mask_mul_ps(EXP, msk, h, _mm512_set1_ps(-1.772453851f));
                __m512 w24 = EXP / _mm512_set1_ps(sigma * sigma) * (_mm512_set1_ps(0.9184481882f) * EXP + _mm512_set1_ps(0.8139535142f) * h);
                msk = _mm512_cmp_ps_mask(w24, _mm512_setzero_ps(), _CMP_GT_OS);
                w24 = _mm512_max_ps(w24, _mm512_setzero_ps());
                __m512 d24 = _mm512_mask_add_ps(dist24, msk, dist24, _mm512_set1_ps(0.5755520493f/sigma) * EXP / w24);
// TEST TEST TEST
//                _mm512_storeu_ps(hharr, h);
//                _mm512_storeu_ps(harr, dist24);
//                _mm512_storeu_ps(darr, d24);
//                _mm512_storeu_ps(warr, w24);
//                for(int j=0 ; j<16 ; j++){
//                    float ddd,www ;
//                    parabola(harr[j], 0, &ddd, &www);
////if(harr[j]<3)
//                    if(www>1e-10 &&(abs((ddd-darr[j]))>0.1 || abs((www-warr[j])/www)>0.1))
//                        printf("-. %f %f %f %f %f %f %f %f\n", hharr[j], harr[j], darr[j], ddd, warr[j], www, abs((ddd-darr[j])), abs((www-warr[j])/www));
//                    if(drand48()<1.e-2 || warr[j]<0)
//                        printf("\t\t-. 24 %f %f %f %f %f %f %f\n", harr[j], darr[j], ddd, warr[j], www, abs((ddd-darr[j])), abs((www-warr[j])/www));
//                }
// END TEST
                msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist24), _mm512_setzero_epi32());
                dist24 = _mm512_mask_div_ps(dist24, msk, d24, dist24);
//if(!i) printvec(dist24);
//#pragma omp critical
//                {
//                if(!i){
//                    printf("dij\n"); printvec(d12); printvec(d13);printvec(d24);printf("\nwij\n");
//                    printvec(w12); printvec(w13); printvec(w24);printf("\nsij\n");
//                    printvec(dist12); printvec(dist13); printvec(dist24);printf("\nverti\n");
//                    printveci(verti1); printveci(verti2); printveci(verti3); printveci(verti4);
//                }
//                float w12a[16]; _mm512_storeu_ps(w12a, w12);
//                float w13a[16]; _mm512_storeu_ps(w13a, w13);
//                float w24a[16]; _mm512_storeu_ps(w24a, w24);
//                float dist12a[16]; _mm512_storeu_ps(dist12a, dist12);
//                float dist13a[16]; _mm512_storeu_ps(dist13a, dist13);
//                float dist24a[16]; _mm512_storeu_ps(dist24a, dist24);
//                int verti1a[16]; _mm512_storeu_si512(verti1a, verti1);
//                int verti2a[16]; _mm512_storeu_si512(verti2a, verti2);
//                int verti3a[16]; _mm512_storeu_si512(verti3a, verti3);
//                int verti4a[16]; _mm512_storeu_si512(verti4a, verti4);
//                for(int k=0 ; k<16 ; k++){
//                    denomverta[verti1a[k]] += w12a[k] + w13a[k] ;
//                    denomverta[verti2a[k]] += w12a[k] + w24a[k] ;
//                    denomverta[verti3a[k]] += w13a[k] ;
//                    denomverta[verti4a[k]] += w24a[k] ;
//                    for (int j=0 ; j<d ; j++){
//                        nom_coord[verti1a[k] + j*n] += w12a[k] * (v[verti2a[k] + j*n] + dist12a[k] * (v[verti1a[k] + j*n] - v[verti2a[k] + j*n]) );
//                        nom_coord[verti1a[k] + j*n] += w13a[k] * (v[verti3a[k] + j*n] + dist13a[k] * (v[verti1a[k] + j*n] - v[verti3a[k] + j*n]) );
//                        nom_coord[verti2a[k] + j*n] += w12a[k] * (v[verti1a[k] + j*n] + dist12a[k] * (v[verti2a[k] + j*n] - v[verti1a[k] + j*n]) );
//                        nom_coord[verti2a[k] + j*n] += w24a[k] * (v[verti4a[k] + j*n] + dist24a[k] * (v[verti2a[k] + j*n] - v[verti4a[k] + j*n]) );
//                        nom_coord[verti3a[k] + j*n] += w13a[k] * (v[verti1a[k] + j*n] + dist13a[k] * (v[verti3a[k] + j*n] - v[verti1a[k] + j*n]) );
//                        nom_coord[verti4a[k] + j*n] += w24a[k] * (v[verti2a[k] + j*n] + dist24a[k] * (v[verti4a[k] + j*n] - v[verti2a[k] + j*n]) );
//                    }
//                }
                    __m512 denomv1n = _mm512_i32gather_ps(verti1, denomverta, 4) + w12 + w13;
                    _mm512_i32scatter_ps(denomverta, verti1, denomv1n, 4);
                    __m512 denomv2n = _mm512_i32gather_ps(verti2, denomverta, 4) + w12 + w24;
                    _mm512_i32scatter_ps(denomverta, verti2, denomv2n, 4);
                    __m512 denomv3n = _mm512_i32gather_ps(verti3, denomverta, 4) + w13;
                    _mm512_i32scatter_ps(denomverta, verti3, denomv3n, 4);
                    __m512 denomv4n = _mm512_i32gather_ps(verti4, denomverta, 4) + w24;
                    _mm512_i32scatter_ps(denomverta, verti4, denomv4n, 4);
//                    _mm512_i32scatter_epi32(oldpartners3, edges, verti3, 4);
//                    _mm512_i32scatter_epi32(oldpartners4, edges, verti4, 4);
//                    _mm512_i32scatter_ps(denome12, edges, w12, 4);
//                    _mm512_i32scatter_ps(denome13, edges, w13, 4);
//                    _mm512_i32scatter_ps(denome24, edges, w24, 4);
                    for (int j = 0; j < d; j++) {
                        __m512 v1 = _mm512_i32gather_ps(verti1, v + j*n, 4);
                        __m512 v2 = _mm512_i32gather_ps(verti2, v + j*n, 4);
                        __m512 v3 = _mm512_i32gather_ps(verti3, v + j*n, 4);
                        __m512 v4 = _mm512_i32gather_ps(verti4, v + j*n, 4);
                        // first nodes of the sampled edges
                        __m512 h = w12 * (v2 + dist12 * (v1 - v2)) + w13 * (v3 + dist13 * (v1 - v3));
                        __m512 coord1 = _mm512_i32gather_ps(verti1, nom_coord + j*n, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n, verti1, coord1 + h, 4);
//                        _mm512_i32scatter_ps(nomv1 + j*n, edges, h, 4);
                        // second nodes of the sampled edges
                        h = w12 * (v1 + dist12 * (v2 - v1)) + w24 * (v4 + dist24 * (v2 - v4));
                        __m512 coord2 = _mm512_i32gather_ps(verti2, nom_coord + j*n, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n, verti2, coord2 + h, 4);
//                        _mm512_i32scatter_ps(nomv2 + j*n, edges, h, 4);
                        // sampled partners of first nodes
                        h = w13 * (v1 + dist13 * (v3 - v1));
                        __m512 coord3 = _mm512_i32gather_ps(verti3, nom_coord + j*n, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n, verti3, coord3 + h, 4);
//                        _mm512_i32scatter_ps(nomold3 + j*n, edges, h, 4);
                        // sampled partners of second nodes
                        h = w24 * (v2 + dist24 * (v4 - v2));
                        __m512 coord4 = _mm512_i32gather_ps(verti4, nom_coord + j*n, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n, verti4, coord4 + h, 4);
//                        _mm512_i32scatter_ps(nomold4 + j*n, edges, h, 4);
                    }
//                }
            }
        }
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            for (int i = par * n / NUM_THREADS / 16 * 16; i < (par + 1) * n / NUM_THREADS / 16 * 16; i += 16) {
                __m512 denom = _mm512_loadu_ps(denomverta + i);
                __mmask16 msk = _mm512_cmp_ps_mask(denom, _mm512_setzero_ps(), _CMP_GT_OS);
                for (int j = 0; j < d; j++)
                    _mm512_storeu_ps(v + n * j + i, _mm512_mask_div_ps(_mm512_loadu_ps(v+n*j+i), msk, _mm512_loadu_ps(nom_coord + n * j + i), denom));
            }
        }
        for (int i = n / 16 * 16; i < n; i++)
            if (denomverta[i] > 0)
                for (int j=0 ; j<d ; j++)
                    v[n * j + i] = nom_coord[n * j + i] / denomverta[i];
//        for (int i = 0; i < n; i++){
//            if (denomverta[i] > 0)
//                for (int j = 0; j < d; j++)
//                    v[n * j + i] = nom_coord[n * j + i] / denomverta[i];
//            else printf("DIVIDE BY ZERO %d %d\n", round, i);
//        }
    }
}

void firstIterScatter(int num_rounds) {
    printf("mem?\n");
    nom_coord = (float*) malloc(n * d * 16 * NUM_THREADS * sizeof (float));
    denomverta = (float*) malloc(n*16*NUM_THREADS*sizeof(float));
    nom_coord[n*d*16*NUM_THREADS-1]=1.f;
    denomverta[n*16*NUM_THREADS-1]=1.f;
    printf("memok %ld %ld\n", (long long) nom_coord, (long long) denomverta);
    int row[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    for (int round = 0; round < num_rounds; round++) {
        if(round%100==0)printf("Iteration #%6d\n", round);
        int mup = (m+15)/16*16;
        for(int i=m ; i<mup ; i++){
            int h=drand48()*m ;
            first[i] = first[h];
            second[i] = second[h];
        }
        initrand += 1024;
        memset(denomverta, 0, n*16*NUM_THREADS*sizeof(float));
        memset(nom_coord, 0, n*d*16*NUM_THREADS*sizeof(float));
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            __m512i randstat = _mm512_loadu_si512(row) + _mm512_set1_epi32(par * 16 + initrand);
            __m512 nnn = _mm512_set1_ps((float) n);
            __m512 mmm = _mm512_set1_ps((float) m);
            __m512i ones = _mm512_set1_epi32(1);
            __m512i largeprime = _mm512_set1_epi32(1103515245);
            __m512i nn = _mm512_set1_epi32(n);
            __m512i hashmask = _mm512_set1_epi32(hashsize-1);
//            for (int i = par * m / 16 / NUM_THREADS * 16; i < (par + 1) * m / 16 / NUM_THREADS * 16 + (par == NUM_THREADS - 1 ? m % 16 : 0); i += 16) {
            for (int i = par * mup / 16 / NUM_THREADS * 16; i < (par + 1) * mup / 16 / NUM_THREADS * 16 ; i += 16) {
//                randstat = randstat * largeprime + ones;
//                __m512i edges = _mm512_cvt_roundps_epi32(_mm512_castsi512_ps(
//                        _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
//                        _mm512_set1_epi32(0x3f800000))) * mmm - mmm, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                __m512i edges = _mm512_set1_epi32(i) + _mm512_loadu_si512(row);
                __m512i verti1 = _mm512_i32gather_epi32(edges, first, 4);
                __m512i verti2 = _mm512_i32gather_epi32(edges, second, 4);
                __m512i verti3 = _mm512_setzero_epi32();
                __m512i verti4 = _mm512_setzero_epi32();
                __mmask16 msk = 0xffff;
                while (msk) {
                    randstat = randstat * largeprime + ones;
                    verti3 = _mm512_mask_cvt_roundps_epi32(verti3, msk, _mm512_castsi512_ps(
                            _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                            _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
//                            _mm512_i32gather_epi32(((verti1 * n + verti3) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                            _mm512_i32gather_epi32(_mm512_mullo_epi32(_mm512_mullo_epi32(verti1, nn)+verti3, largeprime) & hashmask, (int*) hash, 1)& ones);
                    msk |= _mm512_cmpeq_epi32_mask(verti1, verti3);
                }
                msk = 0xffff;
                while (msk) {
                    randstat = randstat * largeprime + ones;
                    verti4 = _mm512_mask_cvt_roundps_epi32(verti4, msk, _mm512_castsi512_ps(
                            _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                            _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
//                            _mm512_i32gather_epi32(((verti2 * n + verti4) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                            _mm512_i32gather_epi32(_mm512_mullo_epi32(_mm512_mullo_epi32(verti2, nn)+verti4, largeprime) & hashmask, (int*) hash, 1)& ones);
                    msk |= _mm512_cmpeq_epi32_mask(verti2, verti4);
                }
                __m512 dist12 = _mm512_setzero_ps();
                for (int j = 0; j < d; j++) {
                    __m512 h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti2, v + j*n, 4);
                    dist12 += h*h;
                }
                dist12 = _mm512_sqrt_ps(dist12);

                // parabolaEdge
                __m512 h = (dist12 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562f * sigma);
                __m512 EXP = _cb512_exp_ps(-h * h);
                EXP /= _mm512_max_ps(_mm512_set1_ps(1e-20f), _mm512_set1_ps(1.f) - _cb512_erf_ps(h)) ;
                msk = _mm512_cmp_ps_mask(h, _mm512_set1_ps(2.44459f), _CMP_GT_OS);
                EXP = _mm512_mask_mul_ps(EXP, msk, h, _mm512_set1_ps(1.772453851f));
                __m512 w12 = EXP / _mm512_set1_ps(sigma * sigma) * (_mm512_set1_ps(0.9184481882f) * EXP - _mm512_set1_ps(0.8139535142f) * h);
                msk = _mm512_cmp_ps_mask(w12, _mm512_setzero_ps(), _CMP_GT_OS);
                w12 = _mm512_max_ps(w12, _mm512_setzero_ps());
                __m512 d12 = _mm512_mask_sub_ps(dist12, msk, dist12, _mm512_set1_ps(0.5755520493f/sigma) * EXP / w12);
                msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist12), _mm512_setzero_epi32());
                dist12 = _mm512_mask_div_ps(dist12, msk, d12, dist12);
                // this is actually sij
                __m512 dist13 = _mm512_setzero_ps();
                for (int j = 0; j < d; j++) {
                    __m512 h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti3, v + j*n, 4);
                    dist13 += h*h;
                }
                dist13 = _mm512_sqrt_ps(dist13);
                //parabolaNoEdge
                h = (dist13 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562f * sigma);
                EXP = _cb512_exp_ps(-h * h);
                EXP /= _mm512_max_ps(_mm512_set1_ps(1e-20f), _mm512_set1_ps(1.f) + _cb512_erf_ps(h)) ;
                msk = _mm512_cmp_ps_mask(h, _mm512_set1_ps(-2.44459f), _CMP_LT_OS);
                EXP = _mm512_mask_mul_ps(EXP, msk, h, _mm512_set1_ps(-1.772453851f));
                __m512 w13 = EXP / _mm512_set1_ps(sigma * sigma) * (_mm512_set1_ps(0.9184481882f) * EXP + _mm512_set1_ps(0.8139535142f) * h);
                msk = _mm512_cmp_ps_mask(w13, _mm512_setzero_ps(), _CMP_GT_OS);
                w13 = _mm512_max_ps(w13, _mm512_setzero_ps());
                __m512 d13 = _mm512_mask_add_ps(dist13, msk, dist13, _mm512_set1_ps(0.5755520493f/sigma) * EXP / w13);
                msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist13), _mm512_setzero_epi32());
                dist13 = _mm512_mask_div_ps(dist13, msk, d13, dist13);
                __m512 dist24 = _mm512_setzero_ps();
                for (int j = 0; j < d; j++) {
                    __m512 h = _mm512_i32gather_ps(verti2, v + j*n, 4) - _mm512_i32gather_ps(verti4, v + j*n, 4);
                    dist24 += h*h;
                }
                dist24 = _mm512_sqrt_ps(dist24);
                //parabolaNoEdge
                h = (dist24 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562f * sigma);
                EXP = _cb512_exp_ps(-h * h);
                EXP /= _mm512_max_ps(_mm512_set1_ps(1e-20f), _mm512_set1_ps(1.f) + _cb512_erf_ps(h)) ;
                msk = _mm512_cmp_ps_mask(h, _mm512_set1_ps(-2.44459f), _CMP_LT_OS);
                EXP = _mm512_mask_mul_ps(EXP, msk, h, _mm512_set1_ps(-1.772453851f));
                __m512 w24 = EXP / _mm512_set1_ps(sigma * sigma) * (_mm512_set1_ps(0.9184481882f) * EXP + _mm512_set1_ps(0.8139535142f) * h);
                msk = _mm512_cmp_ps_mask(w24, _mm512_setzero_ps(), _CMP_GT_OS);
                w24 = _mm512_max_ps(w24, _mm512_setzero_ps());
                __m512 d24 = _mm512_mask_add_ps(dist24, msk, dist24, _mm512_set1_ps(0.5755520493f/sigma) * EXP / w24);
                msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist24), _mm512_setzero_epi32());
                dist24 = _mm512_mask_div_ps(dist24, msk, d24, dist24);
                    __m512i spread = _mm512_mullo_epi32(_mm512_loadu_si512(row) , _mm512_set1_epi32(n)) + _mm512_set1_epi32(16*par*n);
                    __m512 denomv1n = _mm512_i32gather_ps(verti1+spread, denomverta, 4) + w12 + w13;
                    _mm512_i32scatter_ps(denomverta, verti1+spread, denomv1n, 4);
                    __m512 denomv2n = _mm512_i32gather_ps(verti2+spread, denomverta, 4) + w12 + w24;
                    _mm512_i32scatter_ps(denomverta, verti2+spread, denomv2n, 4);
                    __m512 denomv3n = _mm512_i32gather_ps(verti3+spread, denomverta, 4) + w13;
                    _mm512_i32scatter_ps(denomverta, verti3+spread, denomv3n, 4);
                    __m512 denomv4n = _mm512_i32gather_ps(verti4+spread, denomverta, 4) + w24;
                    _mm512_i32scatter_ps(denomverta, verti4+spread, denomv4n, 4);
//                    _mm512_i32scatter_epi32(oldpartners3, edges, verti3, 4);
//                    _mm512_i32scatter_epi32(oldpartners4, edges, verti4, 4);
//                    _mm512_i32scatter_ps(denome12, edges, w12, 4);
//                    _mm512_i32scatter_ps(denome13, edges, w13, 4);
//                    _mm512_i32scatter_ps(denome24, edges, w24, 4);
                    for (int j = 0; j < d; j++) {
                        __m512 v1 = _mm512_i32gather_ps(verti1, v + j*n, 4);
                        __m512 v2 = _mm512_i32gather_ps(verti2, v + j*n, 4);
                        __m512 v3 = _mm512_i32gather_ps(verti3, v + j*n, 4);
                        __m512 v4 = _mm512_i32gather_ps(verti4, v + j*n, 4);
                        // first nodes of the sampled edges
                        __m512 h = w12 * (v2 + dist12 * (v1 - v2)) + w13 * (v3 + dist13 * (v1 - v3));
                        __m512 coord1 = _mm512_i32gather_ps(verti1+spread, nom_coord + j*n*16*NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n*16*NUM_THREADS, verti1+spread, coord1 + h, 4);
//                        _mm512_i32scatter_ps(nomv1 + j*n, edges, h, 4);
                        // second nodes of the sampled edges
                        h = w12 * (v1 + dist12 * (v2 - v1)) + w24 * (v4 + dist24 * (v2 - v4));
                        __m512 coord2 = _mm512_i32gather_ps(verti2+spread, nom_coord + j*n*16*NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n*16*NUM_THREADS, verti2+spread, coord2 + h, 4);
//                        _mm512_i32scatter_ps(nomv2 + j*n, edges, h, 4);
                        // sampled partners of first nodes
                        h = w13 * (v1 + dist13 * (v3 - v1));
                        __m512 coord3 = _mm512_i32gather_ps(verti3+spread, nom_coord + j*n*16*NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n*16*NUM_THREADS, verti3+spread, coord3 + h, 4);
//                        _mm512_i32scatter_ps(nomold3 + j*n, edges, h, 4);
                        // sampled partners of second nodes
                        h = w24 * (v2 + dist24 * (v4 - v2));
                        __m512 coord4 = _mm512_i32gather_ps(verti4+spread, nom_coord + j*n*16*NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j*n*16*NUM_THREADS, verti4+spread, coord4 + h, 4);
//                        _mm512_i32scatter_ps(nomold4 + j*n, edges, h, 4);
                    }
//                }
            }
            // ASYNCHRONOUS CONSOLIDATE
//            for(;;) {
//                int localToCons;
//#pragma omp critical
//                {
//                    localToCons = toCons;
//                    if(localToCons == -1)
//                        toCons = par;
//                }
//                if(localToCons != -1){
//                    for(int i=0 ; i<n ; i++){
//                        for(int k=0 ; k<16 ; k++){
//                            denomverta[i+(par*16+k)*n] += denomverta[i+(localToCons*16+k)*n];
//                            for(int j=0 ; j<d ; j++)
//                                nom_coord[i + (par*16+k) * n + j *n*16*NUM_THREADS] += nom_coord[i + (localToCons*16+k) * n + j *n*16*NUM_THREADS];
//                        }
//                    }
//                } else break ;
//            }
            
        }
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            for (int i = par * n / NUM_THREADS / 16 * 16; i < (par + 1) * n / NUM_THREADS / 16 * 16; i += 16) {
                __m512 denom = _mm512_setzero_ps() ;
                for(int k=0 ; k<16*NUM_THREADS ; k++)
                    denom += _mm512_loadu_ps(denomverta + i + n*k);
                __mmask16 msk = _mm512_cmp_ps_mask(denom, _mm512_setzero_ps(), _CMP_GT_OS);
                for (int j = 0; j < d; j++){
                    __m512 numerator = _mm512_setzero_ps() ;
                    for(int k=0 ; k<16*NUM_THREADS ; k++)
                        numerator += _mm512_loadu_ps(nom_coord + i + n*k + n*16*NUM_THREADS*j);
                    _mm512_storeu_ps(v + n * j + i, _mm512_mask_div_ps(_mm512_loadu_ps(v+n*j+i), msk, numerator, denom));
                }
            }
        }
        
        for (int i = n / 16 * 16; i < n; i++) {
            float den = 0.f;
            for (int k = 0; k < 16 * NUM_THREADS; k++)
                den += denomverta[i + k * n];
            if (den > 0)
                for (int j = 0; j < d; j++) {
                    float h=0 ;
                    for (int k = 0; k < 16 * NUM_THREADS; k++)
                        h += nom_coord[i + k * n + j *n*16*NUM_THREADS];
                    v[n * j + i] = h/den;
                }
        }
    }
}

void sampleDistancesToHistom(int num) {
    memset(histom, 0, 256*sizeof(int));
    int row[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    __m512i ROW = _mm512_loadu_si512(row);
    __m512i ones = _mm512_set1_epi32(1);
    __m512i randstat = ROW + _mm512_set1_epi32(initrand);
    __m512 nnn = _mm512_set1_ps((float) n);
    __m512i largeprime = _mm512_set1_epi32(1103515245);
    __m512i nn = _mm512_set1_epi32(n);
    __m512 c75 = _mm512_set1_ps(7.5f);
    __m512 c0 = _mm512_setzero_ps();
    __m512i c255 = _mm512_set1_epi32(255);
    for (int i = 0; i < num / 16; i++) {
        __m512i verti3 = _mm512_setzero_epi32();
        __m512i verti4 = _mm512_setzero_epi32();
        __m512i hashmask = _mm512_set1_epi32(hashsize - 1);
        randstat = randstat * largeprime + ones;
        __mmask16 msk = 0xffff;
        verti3 = _mm512_mask_cvt_roundps_epi32(verti3, msk, _mm512_castsi512_ps(
                _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
        while (msk) {
            randstat = randstat * largeprime + ones;
            verti4 = _mm512_mask_cvt_roundps_epi32(verti4, msk, _mm512_castsi512_ps(
                    _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                    _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
            msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
                    //                            _mm512_i32gather_epi32(((verti2 * n + verti4) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                    _mm512_i32gather_epi32(_mm512_mullo_epi32(_mm512_mullo_epi32(verti3, nn) + verti4, largeprime) & hashmask, (int*) hash, 1) & ones);
            msk |= _mm512_cmpeq_epi32_mask(verti3, verti4);
        }
        __m512 h;
        __m512 dist12 = _mm512_setzero_ps();
        for (int j = 0; j < d; j++) {
            h = _mm512_i32gather_ps(verti3, v + j*n, 4) - _mm512_i32gather_ps(verti4, v + j*n, 4);
            dist12 += h*h;
        }
        dist12 = _mm512_sqrt_ps(dist12);
        __m512i idx = _mm512_min_epi32(c255, _mm512_cvt_roundps_epi32(dist12 * c75, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
        _mm512_i32scatter_epi32(histom, idx, _mm512_i32gather_epi32(idx, histom, 4) + ones, 4);
    }
}

void firstIterApprox(int num_rounds) {
    nom_coord = (float*) malloc(n * d * 16 * NUM_THREADS * sizeof (float));
    denomverta = (float*) malloc(n*16*NUM_THREADS*sizeof(float));
    nom_coord[n*d*16*NUM_THREADS-1]=1.f;
    denomverta[n*16*NUM_THREADS-1]=1.f;
    int row[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    float a[] = {0.f, 3.643839659e-14f, 8.025775889e-10f, 0.000002391756971f, 0.0009630309489f, 0.05264270870f, 0.3487847716f, 0.2833288512f, 0.1047041485f, 0.04062593758f, 0.02871404198f, -0.01346640946f, -0.01244761323f, -0.04119400318f, 0.f, 0.f};
    float b[] = {0.f, 4.736991556e-13f, 8.82835347e-9f, 0.00002152581274f, 0.006741216642f, 0.2632135435f, 1.165507311f, 1.100051390f, 1.278676093f, 1.470910726f, 1.530470204f, 1.825733364f, 1.816564198f, 2.132774487f, 1.79975605f, 1.772453851f};
    float c[] = {0.f, 1.539522256e-12f, 2.427800850e-8f, 0.00004843388127f, 0.01179952168f, 0.3299823529f, 1.016363980f, 1.0f, 0.9553438243f, 0.8111678497f, 0.7367185022f, 0.2200079720f, 0.2406385956f, -0.6289396998f, -0.20476649f, 0.f};
    for (int round = 0; round < num_rounds; round++) {
        if(round < 10 || round < 100 && round %10 == 0 || round < 1000 && round%100 == 0 || round %1000 == 0)
            printf("Iteration #%6d\n", round);
        int mup = (m+15)/16*16;
        for(int i=m ; i<mup ; i++){
            int h=drand48()*m ;
            first[i] = first[h];
            second[i] = second[h];
        }
        initrand += 1024;
        memset(denomverta, 0, n*16*NUM_THREADS*sizeof(float));
        memset(nom_coord, 0, n*d*16*NUM_THREADS*sizeof(float));
        memset(histop, 0, 256*sizeof(int));
        memset(histom, 0, 256*sizeof(int));
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            __m512i ROW = _mm512_loadu_si512(row);
            __m512i ones = _mm512_set1_epi32(1);
            __m512i randstat = ROW + _mm512_set1_epi32(par * 16 + initrand);
            __m512 A = _mm512_loadu_ps(a);
            __m512 B = _mm512_loadu_ps(b);
            __m512 C = _mm512_loadu_ps(c);
//            for (int i = par * m / 16 / NUM_THREADS * 16; i < (par + 1) * m / 16 / NUM_THREADS * 16 + (par == NUM_THREADS - 1 ? m % 16 : 0); i += 16) {
            for (int i = par * mup / 16 / NUM_THREADS * 16; i < (par + 1) * mup / 16 / NUM_THREADS * 16; i += 16) {
//                randstat = randstat * largeprime + ones;
//                __m512i edges = _mm512_cvt_roundps_epi32(_mm512_castsi512_ps(
//                        _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
//                        _mm512_set1_epi32(0x3f800000))) * mmm - mmm, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                __m512i verti1, verti2, verti3, verti4;
                __m512 dist12, dist13, dist24;
                __m512 w12, w13, w24;
                { // BLOCK FOR RANDOM GENERATOR OF EDGES AND NON-EDGE NODE PAIRS
                    __m512i edges = _mm512_set1_epi32(i) + ROW;
                    verti1 = _mm512_i32gather_epi32(edges, first, 4);
                    verti2 = _mm512_i32gather_epi32(edges, second, 4);
                    verti3 = _mm512_setzero_epi32();
                    verti4 = _mm512_setzero_epi32();
                    __m512 nnn = _mm512_set1_ps((float) n);
                    __m512i largeprime = _mm512_set1_epi32(1103515245);
                    __m512i nn = _mm512_set1_epi32(n);
                    __mmask16 msk = 0xffff;
                    __m512i hashmask = _mm512_set1_epi32(hashsize - 1);
                    while (msk) {
                        randstat = randstat * largeprime + ones;
                        verti3 = _mm512_mask_cvt_roundps_epi32(verti3, msk, _mm512_castsi512_ps(
                                _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                                _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                        msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
                                //                            _mm512_i32gather_epi32(((verti1 * n + verti3) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                                _mm512_i32gather_epi32(_mm512_mullo_epi32(_mm512_mullo_epi32(verti1, nn) + verti3, largeprime) & hashmask, (int*) hash, 1) & ones);
                        msk |= _mm512_cmpeq_epi32_mask(verti1, verti3);
                    }
                    msk = 0xffff;
                    while (msk) {
                        randstat = randstat * largeprime + ones;
                        verti4 = _mm512_mask_cvt_roundps_epi32(verti4, msk, _mm512_castsi512_ps(
                                _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
                                _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                        msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(),
                                //                            _mm512_i32gather_epi32(((verti2 * n + verti4) * largeprime) & hashmask, (int*) (hash), 1) & ones);
                                _mm512_i32gather_epi32(_mm512_mullo_epi32(_mm512_mullo_epi32(verti2, nn) + verti4, largeprime) & hashmask, (int*) hash, 1) & ones);
                        msk |= _mm512_cmpeq_epi32_mask(verti2, verti4);
                    }
                }
                { // BLOCK FOR DETERMINATION OF THE PARABOLAS
                    __m512 h;
                    __m512 c75 = _mm512_set1_ps(7.5f);
                    __m512 c0 = _mm512_setzero_ps();
                    __m512 csigsig = _mm512_set1_ps(1.f / sigma / sigma);
                    __m512 c141sig = _mm512_set1_ps(0.7071067810f / sigma);
                    __m512 c57sig = _mm512_set1_ps(0.5755520493f / sigma);
                    __m512 c91 = _mm512_set1_ps(0.9184481882f);
                    __m512 c81 = _mm512_set1_ps(0.8139535142f);
                    __m512 cmu = _mm512_set1_ps(mu);
                    __m512i c255 = _mm512_set1_epi32(255);
                    dist12 = _mm512_setzero_ps();
                    for (int j = 0; j < d; j++) {
                        h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti2, v + j*n, 4);
                        dist12 += h*h;
                    }
                    dist12 = _mm512_sqrt_ps(dist12);
                    __m512i idx = _mm512_min_epi32(c255,_mm512_cvt_roundps_epi32(dist12 * c75, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
                    _mm512_i32scatter_epi32(histop, idx, _mm512_i32gather_epi32(idx, histop, 4) + ones, 4);

                    // parabolaEdge
                    h = (dist12 - cmu) * c141sig;
                    idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, h) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    __m512 EXP = (_mm512_permutexvar_ps(idx, A) * h + _mm512_permutexvar_ps(idx, B)) * h + _mm512_permutexvar_ps(idx, C);
                    w12 = EXP * csigsig * (c91 * EXP - c81 * h);
                    __mmask16 msk = _mm512_cmp_ps_mask(w12, _mm512_setzero_ps(), _CMP_GT_OS);
                    w12 = _mm512_max_ps(w12, _mm512_setzero_ps());
                    h = _mm512_mask_sub_ps(dist12, msk, dist12, c57sig * EXP / w12);
                    // msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist12), _mm512_setzero_epi32());
                    msk = _mm512_cmp_ps_mask(dist12, c0, _CMP_NEQ_OS);
                    dist12 = _mm512_mask_div_ps(dist12, msk, h, dist12);
                    // this is actually sij
                    dist13 = _mm512_setzero_ps();
                    for (int j = 0; j < d; j++) {
                        h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti3, v + j*n, 4);
                        dist13 += h*h;
                    }
                    dist13 = _mm512_sqrt_ps(dist13);
                    idx = _mm512_min_epi32(c255,_mm512_cvt_roundps_epi32(dist13 * c75, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
                    _mm512_i32scatter_epi32(histom, idx, _mm512_i32gather_epi32(idx, histom, 4) + ones, 4);

                    //parabolaNoEdge
                    h = (dist13 - cmu) * c141sig;
                    idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, c0-h) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    //idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(_mm512_setzero_ps(), _mm512_set1_ps(7.5) - h), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    //idx = _mm512_min_epi32(idx, _mm512_set1_epi32(15));
                    EXP = (_mm512_permutexvar_ps(idx, A) * h - _mm512_permutexvar_ps(idx, B)) * h + _mm512_permutexvar_ps(idx, C);
                    w13 = EXP * csigsig * (c91 * EXP + c81 * h);
                    msk = _mm512_cmp_ps_mask(w13, _mm512_setzero_ps(), _CMP_GT_OS);
                    w13 = _mm512_max_ps(w13, _mm512_setzero_ps());
                    h = _mm512_mask_add_ps(dist13, msk, dist13, c57sig * EXP / w13);
                    // msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist13), _mm512_setzero_epi32());
                    msk = _mm512_cmp_ps_mask(dist13, c0, _CMP_NEQ_OS);
                    dist13 = _mm512_mask_div_ps(dist13, msk, h, dist13);
                    dist24 = _mm512_setzero_ps();
                    for (int j = 0; j < d; j++) {
                        h = _mm512_i32gather_ps(verti2, v + j*n, 4) - _mm512_i32gather_ps(verti4, v + j*n, 4);
                        dist24 += h*h;
                    }
                    dist24 = _mm512_sqrt_ps(dist24);
                    idx = _mm512_min_epi32(c255,_mm512_cvt_roundps_epi32(dist24 * c75, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
                    _mm512_i32scatter_epi32(histom, idx, _mm512_i32gather_epi32(idx, histom, 4) + ones, 4);

                    //parabolaNoEdge
                    h = (dist24 - cmu) * c141sig;
                    idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, c0-h) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    //idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(_mm512_setzero_ps(), _mm512_set1_ps(7.5) - h), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    //idx = _mm512_min_epi32(idx, _mm512_set1_epi32(15));
                    EXP = (_mm512_permutexvar_ps(idx, A) * h - _mm512_permutexvar_ps(idx, B)) * h + _mm512_permutexvar_ps(idx, C);
                    w24 = EXP * csigsig * (c91 * EXP + c81 * h);
                    msk = _mm512_cmp_ps_mask(w24, _mm512_setzero_ps(), _CMP_GT_OS);
                    w24 = _mm512_max_ps(w24, _mm512_setzero_ps());
                    h = _mm512_mask_add_ps(dist24, msk, dist24, c57sig * EXP / w24);
                    // msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist24), _mm512_setzero_epi32());
                    msk = _mm512_cmp_ps_mask(dist24, c0, _CMP_NEQ_OS);
                    dist24 = _mm512_mask_div_ps(dist24, msk, h, dist24);
                }
                { // BLOCK FOR WEIGHTED MAJORIZATION
                    __m512i spread = _mm512_mullo_epi32(ROW, _mm512_set1_epi32(n)) + _mm512_set1_epi32(16 * par * n);
//                    __m512i spread = _mm512_set1_epi32(16 * par * n); // FOR QUICK SIMULATION OF NO DUPLICATION AMONG VECTORS (USE IN COMBINATION WITH CONFLICT-FREE EDGES)
                    __m512 denomv1n = _mm512_i32gather_ps(verti1 + spread, denomverta, 4) + w12 + w13;
                    _mm512_i32scatter_ps(denomverta, verti1 + spread, denomv1n, 4);
                    __m512 denomv2n = _mm512_i32gather_ps(verti2 + spread, denomverta, 4) + w12 + w24;
                    _mm512_i32scatter_ps(denomverta, verti2 + spread, denomv2n, 4);
                    __m512 denomv3n = _mm512_i32gather_ps(verti3 + spread, denomverta, 4) + w13;
                    _mm512_i32scatter_ps(denomverta, verti3 + spread, denomv3n, 4);
                    __m512 denomv4n = _mm512_i32gather_ps(verti4 + spread, denomverta, 4) + w24;
                    _mm512_i32scatter_ps(denomverta, verti4 + spread, denomv4n, 4);
                    //                    _mm512_i32scatter_epi32(oldpartners3, edges, verti3, 4);
                    //                    _mm512_i32scatter_epi32(oldpartners4, edges, verti4, 4);
                    //                    _mm512_i32scatter_ps(denome12, edges, w12, 4);
                    //                    _mm512_i32scatter_ps(denome13, edges, w13, 4);
                    //                    _mm512_i32scatter_ps(denome24, edges, w24, 4);
                    for (int j = 0; j < d; j++) {
                        __m512 v1 = _mm512_i32gather_ps(verti1, v + j*n, 4);
                        __m512 v2 = _mm512_i32gather_ps(verti2, v + j*n, 4);
                        __m512 v3 = _mm512_i32gather_ps(verti3, v + j*n, 4);
                        __m512 v4 = _mm512_i32gather_ps(verti4, v + j*n, 4);
                        // first nodes of the sampled edges
                        __m512 h = w12 * (v2 + dist12 * (v1 - v2)) + w13 * (v3 + dist13 * (v1 - v3));
                        __m512 coord1 = _mm512_i32gather_ps(verti1 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti1 + spread, coord1 + h, 4);
                        //                        _mm512_i32scatter_ps(nomv1 + j*n, edges, h, 4);
                        // second nodes of the sampled edges
                        h = w12 * (v1 + dist12 * (v2 - v1)) + w24 * (v4 + dist24 * (v2 - v4));
                        __m512 coord2 = _mm512_i32gather_ps(verti2 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti2 + spread, coord2 + h, 4);
                        //                        _mm512_i32scatter_ps(nomv2 + j*n, edges, h, 4);
                        // sampled partners of first nodes
                        h = w13 * (v1 + dist13 * (v3 - v1));
                        __m512 coord3 = _mm512_i32gather_ps(verti3 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti3 + spread, coord3 + h, 4);
                        //                        _mm512_i32scatter_ps(nomold3 + j*n, edges, h, 4);
                        // sampled partners of second nodes
                        h = w24 * (v2 + dist24 * (v4 - v2));
                        __m512 coord4 = _mm512_i32gather_ps(verti4 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti4 + spread, coord4 + h, 4);
                        //                        _mm512_i32scatter_ps(nomold4 + j*n, edges, h, 4);
                    }
                }
                //                }
            }
            // ASYNCHRONOUS CONSOLIDATE
//            for(;;) {
//                int localToCons;
//#pragma omp critical
//                {
//                    localToCons = toCons;
//                    if(localToCons == -1)
//                        toCons = par;
//                }
//                if(localToCons != -1){
//                    for(int i=0 ; i<n ; i++){
//                        for(int k=0 ; k<16 ; k++){
//                            denomverta[i+(par*16+k)*n] += denomverta[i+(localToCons*16+k)*n];
//                            for(int j=0 ; j<d ; j++)
//                                nom_coord[i + (par*16+k) * n + j *n*16*NUM_THREADS] += nom_coord[i + (localToCons*16+k) * n + j *n*16*NUM_THREADS];
//                        }
//                    }
//                } else break ;
//            }
            
        }
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            for (int i = par * n / NUM_THREADS / 16 * 16; i < (par + 1) * n / NUM_THREADS / 16 * 16; i += 16) {
                __m512 denom = _mm512_setzero_ps() ;
                for(int k=0 ; k<16*NUM_THREADS ; k++)
                    denom += _mm512_loadu_ps(denomverta + i + n*k);
                __mmask16 msk = _mm512_cmp_ps_mask(denom, _mm512_setzero_ps(), _CMP_GT_OS);
                for (int j = 0; j < d; j++){
                    __m512 numerator = _mm512_setzero_ps() ;
                    for(int k=0 ; k<16*NUM_THREADS ; k++)
                        numerator += _mm512_loadu_ps(nom_coord + i + n*k + n*16*NUM_THREADS*j);
                    _mm512_storeu_ps(v + n * j + i, _mm512_mask_div_ps(_mm512_loadu_ps(v+n*j+i), msk, numerator, denom));
                }
            }
        }
        
        for (int i = n / 16 * 16; i < n; i++) {
            float den = 0.f;
            for (int k = 0; k < 16 * NUM_THREADS; k++)
                den += denomverta[i + k * n];
            if (den > 0)
                for (int j = 0; j < d; j++) {
                    float h=0 ;
                    for (int k = 0; k < 16 * NUM_THREADS; k++)
                        h += nom_coord[i + k * n + j *n*16*NUM_THREADS];
                    v[n * j + i] = h/den;
                }
        }
    }
}

void update(int num_rounds) {
    int initrand = 1235;
    int row[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
#pragma omp parallel for
    for (int par = 0; par < NUM_THREADS; par++) {
        __m512i randstat = _mm512_loadu_si512(row) + _mm512_set1_epi32(par * 16 + initrand);
        __m512 nnn = _mm512_set1_ps((float) n);
        __m512 mmm = _mm512_set1_ps((float) m);
        __m512i ones = _mm512_set1_epi32(1);
        __m512i largeprime = _mm512_set1_epi32(1103515245);
        __m512i nn = _mm512_set1_epi32(n);
        __m512i hashmask = _mm512_set1_epi32(hashsize - 1) ;
        for (int i = 0 ; i <= m*num_rounds/NUM_THREADS ; i++) {
            randstat = randstat * largeprime + ones;
            __m512i edges = _mm512_cvt_roundps_epi32(_mm512_castsi512_ps(
                            _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)), 
                            _mm512_set1_epi32(0x3f800000))) * mmm - mmm, _MM_FROUND_TO_ZERO |_MM_FROUND_NO_EXC) ;
//            printveci(edges);
            __m512i verti1 = _mm512_i32gather_epi32(edges, first, 4);
//            printveci(verti1);
            __m512i verti2 = _mm512_i32gather_epi32(edges, second, 4);
//            printveci(verti2);
            __m512i verti3 = _mm512_setzero_epi32();
            __m512i verti4 = _mm512_setzero_epi32();
            __mmask16 msk = 0xffff;
            while (msk) {
                randstat = randstat * _mm512_set1_epi32(1103515245) + ones;
                verti3 = _mm512_mask_cvt_roundps_epi32(verti3, msk, _mm512_castsi512_ps(
                        _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)), 
                        _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO |_MM_FROUND_NO_EXC) ;
                msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(), 
                        _mm512_i32gather_epi32(((verti1*n+verti3)*largeprime) & hashmask, (int*)(hash), 1) & ones);
//                printveci(_mm512_i32gather_epi32(((verti1*n+verti3)*largeprime) & hashmask, (int*)(hash), 1) & ones);
//                printveci(verti3);
            }
            msk = 0xffff;
            while (msk) {
                randstat = randstat * _mm512_set1_epi32(1103515245) + ones;
                verti4 = _mm512_mask_cvt_roundps_epi32(verti4, msk, _mm512_castsi512_ps(
                        _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)), 
                        _mm512_set1_epi32(0x3f800000))) * nnn - nnn, _MM_FROUND_TO_ZERO |_MM_FROUND_NO_EXC) ;
                msk = _mm512_cmpneq_epi32_mask(_mm512_setzero_epi32(), 
                        _mm512_i32gather_epi32(((verti2*n+verti4)*largeprime) & hashmask, (int*)(hash), 1) & ones);
//                printveci(_mm512_i32gather_epi32(((verti2*n+verti4)*largeprime) & hashmask, (int*)(hash), 1) & ones);
//                printveci(verti4);
            }
            
            __m512 dist12 = _mm512_setzero_ps();
            for (int j = 0; j < d; j++) {
                __m512 h = _mm512_i32gather_ps(verti1, v+j*n, 4) - _mm512_i32gather_ps(verti2, v+j*n, 4);
                dist12 += h*h;
            }
            dist12 = _mm512_sqrt_ps(dist12);
            // parabolaEdge
            __m512 is2spil2 = _mm512_set1_ps(0.5755520493);
            __m512 minvalue = _mm512_set1_ps(1e-6f);
            __m512 SIGMA = _mm512_set1_ps(sigma);
            __m512 h = (dist12 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562 * sigma);
            __m512 EXP = _cb512_exp_ps(-h * h);
            __m512 ERF = _mm512_min_ps(_mm512_setzero_ps() - minvalue, _cb512_erf_ps(h) - _mm512_set1_ps(1.f));
            __m512 w12 = ((is2spil2 * dist12 - _mm512_set1_ps(0.8633280737)) / SIGMA
                    + _mm512_set1_ps(0.4592240941) * EXP / ERF)
                    * EXP / (SIGMA * SIGMA * ERF);
            msk = _mm512_cmpge_epi32_mask(_mm512_castps_si512(w12), _mm512_setzero_epi32());
            msk &= _mm512_cmpneq_epi32_mask(_mm512_castps_si512(w12), _mm512_set1_epi32(0x7F800000));
            __m512 d12 = is2spil2 * EXP / w12 / SIGMA / ERF;
            d12 = _mm512_castsi512_ps(_mm512_maskz_or_epi32(msk, _mm512_castps_si512(d12), _mm512_castps_si512(d12)));
            w12 = _mm512_castsi512_ps(_mm512_maskz_or_epi32(msk, _mm512_castps_si512(w12), _mm512_castps_si512(w12)));
            d12 += dist12;
            msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist12), _mm512_setzero_epi32()) ;
            dist12 = _mm512_mask_div_ps(dist12, msk, d12, dist12);
            // this is actually sij

            __m512 dist13 = _mm512_setzero_ps();
            for (int j = 0; j < d; j++) {
                __m512 h = _mm512_i32gather_ps(verti1, v+j*n, 4) - _mm512_i32gather_ps(verti3, v+j*n, 4);
                dist13 += h*h;
            }
            dist13 = _mm512_sqrt_ps(dist13);
            //parabolaNoEdge
            h = (dist13 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562 * sigma);
            EXP = _cb512_exp_ps(-h * h);
            ERF = _mm512_max_ps(minvalue, _cb512_erf_ps(h) + _mm512_set1_ps(1.f));
            __m512 w13 = ((is2spil2 * dist13 - _mm512_set1_ps(0.8633280737)) / SIGMA
                    + _mm512_set1_ps(0.4592240941) * EXP / ERF)
                    * EXP / (SIGMA * SIGMA * ERF);
            w13 = _mm512_max_ps(w13, minvalue);
            msk = _mm512_cmpge_epi32_mask(_mm512_castps_si512(w13), _mm512_setzero_epi32());
            msk &= _mm512_cmpneq_epi32_mask(_mm512_castps_si512(w13), _mm512_set1_epi32(0x7F800000));
//            printf("%x\n", msk);
            __m512 d13 = is2spil2 * EXP / w13 / SIGMA / ERF;
            d13 = _mm512_castsi512_ps(_mm512_maskz_or_epi32(msk, _mm512_castps_si512(d13), _mm512_castps_si512(d13)));
            w13 = _mm512_castsi512_ps(_mm512_maskz_or_epi32(msk, _mm512_castps_si512(w13), _mm512_castps_si512(w13)));
            d13 += dist13;
            msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist13), _mm512_setzero_epi32()) ;
            dist13 = _mm512_mask_div_ps(dist13, msk, d13, dist13);

            __m512 dist24 = _mm512_setzero_ps();
            for (int j = 0; j < d; j++) {
                __m512 h = _mm512_i32gather_ps(verti2, v+j*n, 4) - _mm512_i32gather_ps(verti4, v+j*n, 4);
                dist24 += h*h;
            }
            dist24 = _mm512_sqrt_ps(dist24);
            //parabolaNoEdge
            h = (dist24 - _mm512_set1_ps(mu)) / _mm512_set1_ps(1.414213562 * sigma);
            EXP = _cb512_exp_ps(-h * h);
            ERF = _mm512_max_ps(minvalue, _cb512_erf_ps(h) + _mm512_set1_ps(1.f));
            __m512 w24 = ((is2spil2 * dist24 - _mm512_set1_ps(0.8633280737)) / SIGMA
                    + _mm512_set1_ps(0.4592240941) * EXP / ERF)
                    * EXP / (SIGMA * SIGMA * ERF);
            w24 = _mm512_max_ps(w24, minvalue);
            msk = _mm512_cmpge_epi32_mask(_mm512_castps_si512(w24), _mm512_setzero_epi32());
            msk &= _mm512_cmpneq_epi32_mask(_mm512_castps_si512(w24), _mm512_set1_epi32(0x7F800000));
//            printf("%x\n", msk);
            __m512 d24 = is2spil2 * EXP / w24 / SIGMA / ERF;
            d24 = _mm512_castsi512_ps(_mm512_maskz_or_epi32(msk, _mm512_castps_si512(d24), _mm512_castps_si512(d24)));
            w24 = _mm512_castsi512_ps(_mm512_maskz_or_epi32(msk, _mm512_castps_si512(w24), _mm512_castps_si512(w24)));
            d24 += dist24;
            msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist24), _mm512_setzero_epi32()) ;
            dist24 = _mm512_mask_div_ps(dist24, msk, d24, dist24);
#pragma omp critical
            {
                __m512i old3 = _mm512_i32gather_epi32(edges, oldpartners3, 4);
                __m512i old4 = _mm512_i32gather_epi32(edges, oldpartners4, 4);
                __m512 denomv1 = _mm512_i32gather_ps(verti1, denomverta, 4);
                __m512 denomv2 = _mm512_i32gather_ps(verti2, denomverta, 4);
                __m512 denomv3 = _mm512_i32gather_ps(verti3, denomverta, 4);
                __m512 denomv4 = _mm512_i32gather_ps(verti4, denomverta, 4);
                __m512 denomold3 = _mm512_i32gather_ps(old3, denomverta, 4);
                __m512 denomold4 = _mm512_i32gather_ps(old4, denomverta, 4);
                __m512 den12 = _mm512_i32gather_ps(edges,denome12,4);
                __m512 den13 = _mm512_i32gather_ps(edges,denome13,4);
                __m512 den24 = _mm512_i32gather_ps(edges,denome24,4);
                __m512 denomv1n = denomv1 + w12 + w13 - den12 - den13;
                __m512 denomv2n = denomv2 + w12 + w24 - den12 - den24;
                __m512 denomv3n = denomv3 + w13 ;
                __m512 denomv4n = denomv4 + w24 ;
                __m512 denomold3n = denomold3 - den13;
                __m512 denomold4n = denomold4 - den24;
                _mm512_i32scatter_ps(denomverta, verti1, denomv1n, 4);
                _mm512_i32scatter_ps(denomverta, verti2, denomv2n, 4);
                _mm512_i32scatter_ps(denomverta, verti3, denomv3n, 4);
                _mm512_i32scatter_ps(denomverta, verti4, denomv4n, 4);
                _mm512_i32scatter_ps(denomverta, old3, denomold3n, 4);
                _mm512_i32scatter_ps(denomverta, old4, denomold4n, 4);
                _mm512_i32scatter_epi32(oldpartners3, edges, verti3, 4);
                _mm512_i32scatter_epi32(oldpartners4, edges, verti4, 4);
                _mm512_i32scatter_ps(denome12, edges, w12, 4);
                _mm512_i32scatter_ps(denome13, edges, w13, 4);
                _mm512_i32scatter_ps(denome24, edges, w24 ,4);
                for(int j=0 ; j<d ; j++){
                    __m512 coord1 = _mm512_i32gather_ps(verti1, v+j*n, 4) ;
                    __m512 coord2 = _mm512_i32gather_ps(verti2, v+j*n, 4) ;
                    __m512 coord3 = _mm512_i32gather_ps(verti3, v+j*n, 4) ;
                    __m512 coord4 = _mm512_i32gather_ps(verti4, v+j*n, 4) ;
                    // first nodes of the sampled edges
                    __m512 h = w12 * (coord2 + dist12 * (coord1-coord2) ) + w13 * (coord3 + dist13 * (coord1-coord3) ) ;
                    _mm512_i32scatter_ps(v+j*n, verti1, (coord1 * denomv1 + h - _mm512_i32gather_ps(edges,nomv1+j*n,4)) / denomv1n, 4) ;
                    _mm512_i32scatter_ps(nomv1+j*n,edges,h,4);
                    // second nodes of the sampled edges
                    h = w12 * (coord1 + dist12 * (coord2-coord1) ) + w24 * (coord4 + dist24 * (coord2-coord4) ) ;
                    _mm512_i32scatter_ps(v+j*n, verti2, (coord2 * denomv2 + h - _mm512_i32gather_ps(edges,nomv2+j*n,4)) / denomv2n, 4) ;
                    _mm512_i32scatter_ps(nomv2+j*n,edges,h,4);
                    // sampled partners of first nodes
                    h = w13 * (coord1 + dist13 * (coord3-coord1)) ;
                    _mm512_i32scatter_ps(v+j*n, verti3, (coord3 * denomv3 + h) / denomv3n, 4) ;
                    _mm512_i32scatter_ps(v+j*n, old3, (coord3 * denomold3 - _mm512_i32gather_ps(edges, nomold3+j*n, 4)) / denomold3n, 4) ;
                    _mm512_i32scatter_ps(nomold3+j*n,edges,h,4);
                    // sampled partners of second nodes
                    h = w24 * (coord2 + dist24 * (coord4-coord2)) ;
                    _mm512_i32scatter_ps(v+j*n, verti4, (coord4 * denomv4 + h) / denomv4n, 4) ;
                    _mm512_i32scatter_ps(v+j*n, old4, (coord4 * denomold4 - _mm512_i32gather_ps(edges, nomold4+j*n, 4)) / denomold4n, 4) ;
                    _mm512_i32scatter_ps(nomold4+j*n,edges,h,4);
                }
            }
        }
    }
}

int gridCompare2DInd(const void *a, const void *b) {
    int A = * (int *) a;
    int B = * (int *) b;
    int h = (int) (floor(v[A] / EGO_epsilon) - floor(v[B] / EGO_epsilon));
    if (h != 0) return h;
    float hh = v[A+n] - v[B+n];
    if (hh < 0)
        return -1;
    else if (hh > 0)
        return 1;
    return 0;
}

int cmpValues(const void *a, const void *b){
    float A = *(float*) a;
    float B = *(float*) b;
    if (A<B) return -1;
    if (A>B) return 1;
    return 0;
}

int cmpEdges(const void *a, const void *b){
    int *A = (int*) a;
    int *B = (int*) b;
    if(A[0]==B[0])
        if(A[1] == B[1])
            return 0;
        else
            return A[1] < B[1] ? -1 : 1;
    else 
        return A[0] < B[0] ? -1 : 1;
}

void generateBCSR(const char *name){
    long long nn = n;
    long long mm = 2*m;
    int * adj = (int *)malloc(4*m*sizeof(int));
    int * ia = (int *)calloc(n, sizeof(int));
    for(int i=0 ; i<m ; i++){
        adj[2*i] = adj[2*m+2*i+1] = first[i];
        adj[2*i+1] = adj[2*m+2*i] = second[i];
    }
    qsort(adj, 2*m, 8, cmpEdges);
    int j=0 ;
    for(int i=0 ; i<2*m ; i++)
        while(adj[2*i]>j){
            ia[++j]=i;
        }
    for(int i=0 ; i<2*m ; i++)
        adj[i] = adj[2*i+1];
    FILE * bcsr = fopen(name, "w");
    fprintf(bcsr, "XGFS");
    fwrite(&nn, sizeof(long long), 1, bcsr);
    fwrite(&mm, sizeof(long long), 1, bcsr);
    fwrite(ia, sizeof(int), n, bcsr);
    fwrite(adj, sizeof(int), 2*m, bcsr);
    fclose(bcsr);
    free(adj);
    free(ia);
}

void generateAdjList(const char *name){
    long long nn = n;
    long long mm = 2*m;
    int * adj = (int *)malloc(4*m*sizeof(int));
    for(int i=0 ; i<m ; i++){
        adj[2*i] = adj[2*m+2*i+1] = first[i] ;//== 0 ? n : first[i];
        adj[2*i+1] = adj[2*m+2*i] = second[i] ;//== 0 ? n : second[i];
    }
    qsort(adj, 2*m, 8, cmpEdges);
    FILE * bcsr = fopen(name, "w");
    int j=0;
    fprintf(bcsr, "%d %d\n", n, m);
    for(int i=0 ; i<mm ; i++){
        while(adj[2*i] > j){
            fprintf(bcsr, "\n");
            j++;
        }
        fprintf(bcsr, "%d ", adj[2*i+1]+1);
    }
    fclose(bcsr);
    free(adj);
}

void testVar(int N){
    float * a = (float*) malloc(N*sizeof(float));
    int * histo = (int*) calloc(100, sizeof(int));
    for (int round = 0 ; round<1000000/N+1 ; round ++){
    for (int i=0 ; i<N ; i++)
        a[i]=drand48() ;
    qsort(a, N, 4, cmpValues) ;
    for (int i=1 ; i<N ; i++){
        float h = min(0.99,(a[i]-a[i-1]) * N/4);
        histo[(int)(100*h)]++;
    }
    }
    for(int i=0 ; i<100 ; i++)
        printf("%d %f %d\n", i, (float)(i*4)/N, histo[i]);
}

int curI, curJ, curJreset, curSO, curActive;

inline int getNextEgoPair(int *i, int *j) {
    while (curI < n) {
        curJ++;
        if (curSO) { // partner in the next stripe
            if (curJ >= n || v[sortfield[curJ] + n] - v[sortfield[curI] + n] > EGO_epsilon || floor(v[sortfield[curJ]] / EGO_epsilon) > floor(v[sortfield[curI]] / EGO_epsilon) + 1) {
                curSO = 0;
                curJ = ++curI;
            } else {
                if (abs(v[sortfield[curJ]] - v[sortfield[curI]]) < EGO_epsilon) {
                    *i = sortfield[curI];
                    *j = sortfield[curJ];
                    return curActive = 1;
                }
            }
        } else { // partner in the same stripe
            if (curJ >= n || v[sortfield[curJ] + n] - v[sortfield[curI] + n] > EGO_epsilon || floor(v[sortfield[curJ]] / EGO_epsilon) > floor(v[sortfield[curI]] / EGO_epsilon)) {
                curSO = 1;
                while (curJreset < n && floor(v[sortfield[curJreset]] / EGO_epsilon) <= floor(v[sortfield[curI]] / EGO_epsilon))
                    curJreset++;
                while (curJreset < n && floor(v[sortfield[curJreset]] / EGO_epsilon) <= floor(v[sortfield[curI]] / EGO_epsilon) + 1 && v[sortfield[curJreset] + n] < v[sortfield[curI] + n] - EGO_epsilon)
                    curJreset++;
                curJ = --curJreset;
            } else {
                if (abs(v[sortfield[curJ]] - v[sortfield[curI]]) < EGO_epsilon) {
                    *i = sortfield[curI];
                    *j = sortfield[curJ];
                    return curActive = 1;
                }
            }
        }
    }
    do {
        *i = (int) (drand48() * n);
        *j = (int) (drand48() * n);
    } while (*i == *j);
    return curActive = 0;
}

__m512 getNextI(void){
    return _mm512_setzero_ps();
}

void grid2DIterApprox(int num_rounds) {
    nom_coord = (float*) malloc(n * d * 16 * NUM_THREADS * sizeof (float));
    denomverta = (float*) malloc(n*16*NUM_THREADS*sizeof(float));
    nom_coord[n*d*16*NUM_THREADS-1]=1.f;
    denomverta[n*16*NUM_THREADS-1]=1.f;
    int row[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
    float a[] = {0.f, 3.643839659e-14f, 8.025775889e-10f, 0.000002391756971f, 0.0009630309489f, 0.05264270870f, 0.3487847716f, 0.2833288512f, 0.1047041485f, 0.04062593758f, 0.02871404198f, -0.01346640946f, -0.01244761323f, -0.04119400318f, 0.f, 0.f};
    float b[] = {0.f, 4.736991556e-13f, 8.82835347e-9f, 0.00002152581274f, 0.006741216642f, 0.2632135435f, 1.165507311f, 1.100051390f, 1.278676093f, 1.470910726f, 1.530470204f, 1.825733364f, 1.816564198f, 2.132774487f, 1.79975605f, 1.772453851f};
    float c[] = {0.f, 1.539522256e-12f, 2.427800850e-8f, 0.00004843388127f, 0.01179952168f, 0.3299823529f, 1.016363980f, 1.0f, 0.9553438243f, 0.8111678497f, 0.7367185022f, 0.2200079720f, 0.2406385956f, -0.6289396998f, -0.20476649f, 0.f};
    for (int round = 0; round < num_rounds; round++) {
        if(round < 10 || round < 100 && round %10 == 0 || round < 1000 && round%100 == 0 || round %1000 == 0)
            printf("Grid Iteration #%6d (sigma=%f, cost=%f)\n", round, sigma, costFromHist());
        int mup = (m+15)/16*16;
        for(int i=m ; i<mup ; i++){
            int h=drand48()*m ;
            first[i] = first[h];
            second[i] = second[h];
        }
        initrand += 1024;
        memset(denomverta, 0, n*16*NUM_THREADS*sizeof(float));
        memset(nom_coord, 0, n*d*16*NUM_THREADS*sizeof(float));
        memset(histop, 0, 256*sizeof(int));
        memset(histom, 0, 256*sizeof(int));
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            __m512i ROW = _mm512_loadu_si512(row);
            __m512i ones = _mm512_set1_epi32(1);
            __m512i randstat = ROW + _mm512_set1_epi32(par * 16 + initrand);
            __m512 A = _mm512_loadu_ps(a);
            __m512 B = _mm512_loadu_ps(b);
            __m512 C = _mm512_loadu_ps(c);
            int verti1a[16] __attribute__((aligned(64)));
            int verti2a[16] __attribute__((aligned(64)));
//            for (int i = par * m / 16 / NUM_THREADS * 16; i < (par + 1) * m / 16 / NUM_THREADS * 16 + (par == NUM_THREADS - 1 ? m % 16 : 0); i += 16) {
            for (int i = par * mup / 16 / NUM_THREADS * 16; i < (par + 1) * mup / 16 / NUM_THREADS * 16; i += 16) {
//                randstat = randstat * largeprime + ones;
//                __m512i edges = _mm512_cvt_roundps_epi32(_mm512_castsi512_ps(
//                        _mm512_or_epi32(_mm512_and_epi32(randstat, _mm512_set1_epi32(0x7fffff)),
//                        _mm512_set1_epi32(0x3f800000))) * mmm - mmm, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                __m512i verti1, verti2;
                __m512 dist12;
                __m512 w12;
                { // BLOCK FOR RANDOM GENERATOR OF EDGES AND NON-EDGE NODE PAIRS
                    __m512i edges = _mm512_set1_epi32(i) + ROW;
                    verti1 = _mm512_i32gather_epi32(edges, first, 4);
                    verti2 = _mm512_i32gather_epi32(edges, second, 4);
                }
                { // BLOCK FOR DETERMINATION OF THE PARABOLAS
                    __m512 h;
                    __m512 c75 = _mm512_set1_ps(7.5f);
                    __m512 c0 = _mm512_setzero_ps();
                    __m512 csigsig = _mm512_set1_ps(1.f / sigma / sigma);
                    __m512 c141sig = _mm512_set1_ps(0.7071067810f / sigma);
                    __m512 c57sig = _mm512_set1_ps(0.5755520493f / sigma);
                    __m512 c91 = _mm512_set1_ps(0.9184481882f);
                    __m512 c81 = _mm512_set1_ps(0.8139535142f);
                    __m512 cmu = _mm512_set1_ps(mu);
                    __m512i c255 = _mm512_set1_epi32(255);
                    dist12 = _mm512_setzero_ps();
                    for (int j = 0; j < d; j++) {
                        h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti2, v + j*n, 4);
                        dist12 += h*h;
                    }
                    dist12 = _mm512_sqrt_ps(dist12);
                    __m512i idx = _mm512_min_epi32(c255,_mm512_cvt_roundps_epi32(dist12 * c75, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
                    _mm512_i32scatter_epi32(histop, idx, _mm512_i32gather_epi32(idx, histop, 4) + ones, 4);

                    // parabolaEdge
                    h = (dist12 - cmu) * c141sig;
                    idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, h) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    __m512 EXP = (_mm512_permutexvar_ps(idx, A) * h + _mm512_permutexvar_ps(idx, B)) * h + _mm512_permutexvar_ps(idx, C);
                    w12 = EXP * csigsig * (c91 * EXP - c81 * h);
                    __mmask16 msk = _mm512_cmp_ps_mask(w12, _mm512_setzero_ps(), _CMP_GT_OS);
                    w12 = _mm512_max_ps(w12, _mm512_setzero_ps());
                    h = _mm512_mask_sub_ps(dist12, msk, dist12, c57sig * EXP / w12);
                    // msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist12), _mm512_setzero_epi32());
                    msk = _mm512_cmp_ps_mask(dist12, c0, _CMP_NEQ_OS);
                    dist12 = _mm512_mask_div_ps(dist12, msk, h, dist12);
                    // this is actually sij
                }
                { // BLOCK FOR WEIGHTED MAJORIZATION
                    __m512i spread = _mm512_mullo_epi32(ROW, _mm512_set1_epi32(n)) + _mm512_set1_epi32(16 * par * n);
                    __m512 denomv1n = _mm512_i32gather_ps(verti1 + spread, denomverta, 4) + w12;
                    _mm512_i32scatter_ps(denomverta, verti1 + spread, denomv1n, 4);
                    __m512 denomv2n = _mm512_i32gather_ps(verti2 + spread, denomverta, 4) + w12;
                    _mm512_i32scatter_ps(denomverta, verti2 + spread, denomv2n, 4);
                    for (int j = 0; j < d; j++) {
                        __m512 v1 = _mm512_i32gather_ps(verti1, v + j*n, 4);
                        __m512 v2 = _mm512_i32gather_ps(verti2, v + j*n, 4);
                        // first nodes of the sampled edges
                        __m512 h = w12 * (v2 + dist12 * (v1 - v2));
                        __m512 coord1 = _mm512_i32gather_ps(verti1 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti1 + spread, coord1 + h, 4);
                        // second nodes of the sampled edges
                        h = w12 * (v1 + dist12 * (v2 - v1));
                        __m512 coord2 = _mm512_i32gather_ps(verti2 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti2 + spread, coord2 + h, 4);
                    }
                }
            }
            EGO_epsilon = 3.f;
            curI=curJ=curJreset=0;
            qsort(sortfield, n, sizeof (int), gridCompare2DInd);
            while (curI < n) {
                __m512i verti1, verti2;
                __m512 dist12;
                __m512 w12;
                for(int j=0 ; j<16 ; j++)
                    do{
                        getNextEgoPair(verti1a+j, verti2a+j);
//                        if(round==0 && curI==4000)
//                            printf("%6d %6d %f %f %f %f %d\n", verti1a[j], verti2a[j], v[verti1a[j]], v[verti1a[j]+n], v[verti2a[j]], v[verti2a[j]+n], hash[((verti1a[j]*n+verti2a[j])*1103515245) & (hashsize-1)]);
                    }while(hash[((verti1a[j]*n+verti2a[j])*1103515245) & (hashsize-1)]);
                verti1 = _mm512_load_epi32(verti1a);
                verti2 = _mm512_load_epi32(verti2a);
                { // BLOCK FOR DETERMINATION OF THE PARABOLAS
                    __m512 h;
                    __m512 c75 = _mm512_set1_ps(7.5f);
                    __m512 c0 = _mm512_setzero_ps();
                    __m512 csigsig = _mm512_set1_ps(1.f / sigma / sigma);
                    __m512 c141sig = _mm512_set1_ps(0.7071067810f / sigma);
                    __m512 c57sig = _mm512_set1_ps(0.5755520493f / sigma);
                    __m512 c91 = _mm512_set1_ps(0.9184481882f);
                    __m512 c81 = _mm512_set1_ps(0.8139535142f);
                    __m512 cmu = _mm512_set1_ps(mu);
                    __m512i c255 = _mm512_set1_epi32(255);
                    dist12 = _mm512_setzero_ps();
                    for (int j = 0; j < d; j++) {
                        h = _mm512_i32gather_ps(verti1, v + j*n, 4) - _mm512_i32gather_ps(verti2, v + j*n, 4);
                        dist12 += h*h;
                    }
                    dist12 = _mm512_sqrt_ps(dist12);
                    __m512i idx = _mm512_min_epi32(c255,_mm512_cvt_roundps_epi32(dist12 * c75, _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC));
                    _mm512_i32scatter_epi32(histom, idx, _mm512_i32gather_epi32(idx, histom, 4) + ones, 4);
                    h = (dist12 - cmu) * c141sig;
                    idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(c0, _mm512_min_ps(c75, c0-h) + c75), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    //idx = _mm512_cvt_roundps_epi32(_mm512_max_ps(_mm512_setzero_ps(), _mm512_set1_ps(7.5) - h), _MM_FROUND_TO_ZERO | _MM_FROUND_NO_EXC);
                    //idx = _mm512_min_epi32(idx, _mm512_set1_epi32(15));
                    __m512 EXP = (_mm512_permutexvar_ps(idx, A) * h - _mm512_permutexvar_ps(idx, B)) * h + _mm512_permutexvar_ps(idx, C);
                    w12 = EXP * csigsig * (c91 * EXP + c81 * h);
                    __mmask16 msk = _mm512_cmp_ps_mask(w12, _mm512_setzero_ps(), _CMP_GT_OS);
                    w12 = _mm512_max_ps(w12, _mm512_setzero_ps());
                    h = _mm512_mask_add_ps(dist12, msk, dist12, c57sig * EXP / w12);
                    // msk = _mm512_cmpneq_epi32_mask(_mm512_castps_si512(dist12), _mm512_setzero_epi32());
                    msk = _mm512_cmp_ps_mask(dist12, c0, _CMP_NEQ_OS);
                    dist12 = _mm512_mask_div_ps(dist12, msk, h, dist12);
                }
                { // BLOCK FOR WEIGHTED MAJORIZATION
                    __m512i spread = _mm512_mullo_epi32(ROW, _mm512_set1_epi32(n)) + _mm512_set1_epi32(16 * par * n);
                    __m512 denomv1n = _mm512_i32gather_ps(verti1 + spread, denomverta, 4) + w12;
                    _mm512_i32scatter_ps(denomverta, verti1 + spread, denomv1n, 4);
                    __m512 denomv2n = _mm512_i32gather_ps(verti2 + spread, denomverta, 4) + w12;
                    _mm512_i32scatter_ps(denomverta, verti2 + spread, denomv2n, 4);
                    for (int j = 0; j < d; j++) {
                        __m512 v1 = _mm512_i32gather_ps(verti1, v + j*n, 4);
                        __m512 v2 = _mm512_i32gather_ps(verti2, v + j*n, 4);
                        // first nodes of the sampled edges
                        __m512 h = w12 * (v2 + dist12 * (v1 - v2));
                        __m512 coord1 = _mm512_i32gather_ps(verti1 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti1 + spread, coord1 + h, 4);
                        // second nodes of the sampled edges
                        h = w12 * (v1 + dist12 * (v2 - v1));
                        __m512 coord2 = _mm512_i32gather_ps(verti2 + spread, nom_coord + j * n * 16 * NUM_THREADS, 4);
                        _mm512_i32scatter_ps(nom_coord + j * n * 16 * NUM_THREADS, verti2 + spread, coord2 + h, 4);
                    }
                }
            }
        }
#pragma omp parallel for
        for (int par = 0; par < NUM_THREADS; par++) {
            for (int i = par * n / NUM_THREADS / 16 * 16; i < (par + 1) * n / NUM_THREADS / 16 * 16; i += 16) {
                __m512 denom = _mm512_setzero_ps() ;
                for(int k=0 ; k<16*NUM_THREADS ; k++)
                    denom += _mm512_loadu_ps(denomverta + i + n*k);
                __mmask16 msk = _mm512_cmp_ps_mask(denom, _mm512_setzero_ps(), _CMP_GT_OS);
                for (int j = 0; j < d; j++){
                    __m512 numerator = _mm512_setzero_ps() ;
                    for(int k=0 ; k<16*NUM_THREADS ; k++)
                        numerator += _mm512_loadu_ps(nom_coord + i + n*k + n*16*NUM_THREADS*j);
                    _mm512_storeu_ps(v + n * j + i, _mm512_mask_div_ps(_mm512_loadu_ps(v+n*j+i), msk, numerator, denom));
                }
            }
        }
        
        for (int i = n / 16 * 16; i < n; i++) {
            float den = 0.f;
            for (int k = 0; k < 16 * NUM_THREADS; k++)
                den += denomverta[i + k * n];
            if (den > 0)
                for (int j = 0; j < d; j++) {
                    float h=0 ;
                    for (int k = 0; k < 16 * NUM_THREADS; k++)
                        h += nom_coord[i + k * n + j *n*16*NUM_THREADS];
                    v[n * j + i] = h/den;
                }
        }
        sampleDistancesToHistom(100000);
        sigma = sigmaFromHist() ;
    }
}


void randominit(){
    for(int i=0 ; i<n*d ; i++)
        v[i] = drand48() ;
}

void readfile(const char * filename){
    FILE * myfile = fopen(filename, "r");
    fscanf(myfile, "%d\n", &n);
    fscanf(myfile, "%d\n", &m);
    initmem(n,m,1.5f, 1.0f);
    for(int i=0 ; i<m ; i++)
        fscanf(myfile, "%d\n", first+i);
    for(int i=0 ; i<m ; i++)
        fscanf(myfile, "%d\n", second+i);
    if(!feof(myfile)){
        printf("Not end of file\n\n");
        exit(-1);
    }
    int nozero=1;
    int non=1;
    for(int i=0 ; i<m ; i++){
        if(first[i]==0 || second[i] ==0)
            nozero = 0;
        if(first[i] > n || second[i] > n){
            printf("node > n\n");
            exit(-1);
        }
        if(!nozero && first[i] >= n || second[i] >= n){
            printf("node >= n\n");
            exit(-1);
        }
        if(first[i]==n) {first[i]=0 ; non=0;}
        if(second[i]==n) {second[i]=0; non=0;}
        
    }
    if(!non){
        printf("WARNING ELEMENT n HAS BEEN RENAMED TO 0");
        if(!nozero)
            exit(-1);
    }
    for (int i=0 ; i<10 && i<m ; i++)
    printf("Edge[%d]: %d %d\n", i, first[i], second[i]);
    printf("Edge[%d]: %d %d\n", m-1, first[m-1], second[m-1]);
}

void readfile2(const char * filename){
    FILE * myfile = fopen(filename, "r");
    fscanf(myfile, "%d\n", &n);
    fscanf(myfile, "%d\n", &m);
    initmem(n,m,1.5f, 1.0f);
    for(int i=0 ; i<m ; i++)
        fscanf(myfile, "%d %d\n", first+i, second+i);
    if(!feof(myfile)){
        printf("Not end of file\n\n");
        exit(-1);
    }
    int nozero=1;
    int non=1;
    for(int i=0 ; i<m ; i++){
        if(first[i]==0 || second[i] ==0)
            nozero = 0;
        if(first[i] > n || second[i] > n){
            printf("node > n\n");
            exit(-1);
        }
        if(!nozero && first[i] >= n || second[i] >= n){
            printf("node >= n\n");
            exit(-1);
        }
        if(first[i]==n) {first[i]=0 ; non=0;}
        if(second[i]==n) {second[i]=0; non=0;}
        
    }
    if(!non){
        printf("WARNING ELEMENT n HAS BEEN RENAMED TO 0");
        if(!nozero)
            exit(-1);
    }
    for (int i=0 ; i<10 && i<m ; i++)
    printf("Edge[%d]: %d %d\n", i, first[i], second[i]);
    printf("Edge[%d]: %d %d\n", m-1, first[m-1], second[m-1]);
}

void readcoord(const char * filename){
    FILE * myfile = fopen(filename, "r");
    for(int i=0 ; i<n ; i++)
        fscanf(myfile, "%f %f\n", v+i, v+n+i);
}

int cmprandom(const void *a, const void *b){
    if(drand48()>.5)
        return 1;
    return -1;
}

void scrambleEdges(){
    int * scramble = (int*) malloc(m * sizeof(int));
    int * adj_new = (int*) malloc(m * sizeof(int));
    for(int i=0 ; i<m ; i++)
        scramble[i]=i;
    qsort(scramble, m, sizeof(int), cmprandom);
    for(int i=0 ; i<m ; i++)
        adj_new[i] = first[scramble[i]];
    memcpy(first, adj_new, m*sizeof(int));
    for(int i=0 ; i<m ; i++)
        adj_new[i] = second[scramble[i]];
    memcpy(second, adj_new, m*sizeof(int));
    free(adj_new);
    free(scramble);
}

void scrambleCollisions(){
    // forward phase
    scramble = (int*) malloc(m * sizeof(int));
    int * adj_new = (int*) malloc(m * sizeof(int));
    int h=0 ;
    int minProblemEdge = m;
    for(int i=0 ; i<m ; i++)
        scramble[i]=i;
    for(int I=0 ; I<m ; I+=16){
//        for (int i=I ; i<I+16 && i<m ; i++)
//            printf("%2d %3d %3d | ", scramble[i], first[scramble[i]], second[scramble[i]]);
//        printf("\n");
        for(int i=I+1; i<I+16 && i<m ; i++){
            for(int j=I ; j<i ; j++)
                if(first[scramble[i]] == first[scramble[j]] || second[scramble[i]] == second[scramble[j]] || first[scramble[i]] == second[scramble[j]] || second[scramble[i]] == first[scramble[j]]){
                    // i and j have collision: replace i by some k that has no collision in [I..i-1]
                    for(int k=I+16; k<m ; k++){
                        for(int p=I ; p<i ; p++)
                            if(first[scramble[k]] == first[scramble[p]] || second[scramble[k]] == second[scramble[p]] || first[scramble[k]] == second[scramble[p]] || second[scramble[k]] == first[scramble[p]])
                                goto nextk;
                        h=scramble[k];
                        scramble[k] = scramble[i];
                        scramble[i] = h;
                        goto nexti ;
                        nextk: ;
                    }
//                    printf("not found for i=%d [%d]\n", i, scramble[i]);
                    if(minProblemEdge == m)
                        minProblemEdge = i;
                }
            nexti:;
        }
//        for (int i=I ; i<I+16 && i<m ; i++)
//            printf("%2d %3d %3d | ", scramble[i], first[scramble[i]], second[scramble[i]]);
//        printf("\n\n");
    }
    // backward phase
    for(int I=(m-1)/16*16 ; I>=minProblemEdge-16 ; I-=16){
//        for (int i=I ; i<I+16 && i<m ; i++)
//            printf("%2d %3d %3d | ", scramble[i], first[scramble[i]], second[scramble[i]]);
//        printf("\n");
        for(int i=min(I+14, m-2); i>=I ; i--){
            for(int j=min(I+15, m-1) ; j>i ; j--)
                if(first[scramble[i]] == first[scramble[j]] || second[scramble[i]] == second[scramble[j]] || first[scramble[i]] == second[scramble[j]] || second[scramble[i]] == first[scramble[j]]){
                    // i and j have collision: replace i by some k that has no collision in [I..i-1]
                    for(int k=I-1; k>=0 ; k--){
                        for(int p=I ; p<I+16 && p<m ; p++)
                            if(first[scramble[k]] == first[scramble[p]] || second[scramble[k]] == second[scramble[p]] || first[scramble[k]] == second[scramble[p]] || second[scramble[k]] == first[scramble[p]])
                                goto nextk2;
                        for(int p=k/16*16 ; p<k ; p++)
                            if(first[scramble[i]] == first[scramble[p]] || second[scramble[i]] == second[scramble[p]] || first[scramble[i]] == second[scramble[p]] || second[scramble[i]] == first[scramble[p]])
                                goto nextk2;
                        for(int p=k+1 ; p<k/16*16+16 ; p++)
                            if(first[scramble[i]] == first[scramble[p]] || second[scramble[i]] == second[scramble[p]] || first[scramble[i]] == second[scramble[p]] || second[scramble[i]] == first[scramble[p]])
                                goto nextk2;
                        h=scramble[k];
                        scramble[k] = scramble[i];
                        scramble[i] = h;
                        goto nexti2 ;
                        nextk2: ;
                    }
                    printf("not found for i=%d [%d]\n", i, scramble[i]);
                }
            nexti2:;
        }
//        for (int i=I ; i<I+16 && i<m ; i++)
//            printf("%2d %3d %3d | ", scramble[i], first[scramble[i]], second[scramble[i]]);
//        printf("\n\n");
//        
    }
    for(int i=0 ; i<m ; i++)
        adj_new[i] = first[scramble[i]];
    memcpy(first, adj_new, m*sizeof(int));
    for(int i=0 ; i<m ; i++)
        adj_new[i] = second[scramble[i]];
    memcpy(second, adj_new, m*sizeof(int));
    free(adj_new);
    // free(scramble);
    // FINAL CHECK
    int num_collisions = 0;
    for (int I = 0; I < m; I += 16) {
        //        for (int i=I ; i<I+16 && i<m ; i++)
        //            printf("%2d %3d %3d | ", scramble[i], first[scramble[i]], second[scramble[i]]);
        //        printf("\n");
        for (int i = I + 1; i < I + 16 && i < m; i++) {
            for (int j = I; j < i; j++)
                if (first[i] == first[j] || second[i] == second[j] || first[i] == second[j] || second[i] == first[j]) {
                    printf("ERROR COLLISION %d: (i,j) = %d [%d %d] %d  [%d %d]\n", ++num_collisions, i, first[i], second[i], j, first[j], second[j]);
                }
        }
    }
    if (num_collisions > 0)
        exit(-1);
    
}

void process_pubmed(){
    typedef unsigned short int usi;
    FILE * f=fopen("pubmed.nodes", "r");
    usi * hash = (usi *) calloc (25000000, sizeof(usi));
    int * edges = (int *) malloc (1000000*2*sizeof(int));
    printf("Test %ld %ld\n", (long long)hash, (long long) edges);
    int n;
    for(n=1 ; !feof(f) ; n++){
        int i, j;
        fscanf(f, "%d;%d\n", &i, &j);
        printf("%d %d\n",i,j);
        hash[i] = n;
    }
    fclose(f);
    printf("n=%d\n", n);
    f=fopen("pubmed.edges", "r");
    for(m=0 ; m<1000000 && ! feof(f) ; m++){
        int i, j;
        fscanf(f, "%d;%d\n", &i, &j);
        if((i=hash[i])<=0 || i>n || (j=hash[j])<=0 || j>n){
            printf("Error\n");
            exit(-1);
        }
        edges[2*m] = min(i,j)-1;
        edges[2*m+1] = max(i,j)-1;
    }
    fclose(f);
    qsort(edges, m, 8, cmpEdges);
    int duplicates = 0;
    for(int i=1 ; i<m ; i++)
        if(edges[i*2] == edges[i*2-2] && edges[i*2+1] == edges[i*2-1])
            duplicates++ ;
    f=fopen("pubmedAdj","w");
    fprintf(f, "%d %d\n", n-1, m-duplicates);
    for(int i=0 ; i<m ; i++)
        if(!i || edges[i*2] != edges[i*2-2] || edges[i*2+1] != edges[i*2-1])
            fprintf(f, "%d %d\n", edges[i*2], edges[i*2+1]) ;
    fclose(f);
    free(hash);
    free(edges);
    exit(0);
}

int main() {
//    process_pubmed();
//    float farr[] = {1.f, 2.f, .2f, .3f, 5.f, 6.f, 7.f, 8.f, 9.f, 100.f, -1.f, -12.f, -7.5f, -6.5f, -6.f, 0.f};
//    float rarr[16];
//    float marr[16];
//    for (int j=0 ; j<100 ; j++){
//    for (int i=0 ; i<16 ; i++)
//        farr[i] = drand48() * 20. -10.;
//    _mm512_storeu_ps(rarr, quotp(_mm512_loadu_ps(farr)));
//    _mm512_storeu_ps(marr, quotm(_mm512_loadu_ps(farr)));
//    for (int i=0 ; i<16 ; i++)
//        printf("%f %e %e\n", farr[i], rarr[i], marr[i]);
//    }
//    n = 1024 ;
//    m = 65536 ;
//    initmem(1024,65536,1.5f,1.0f) ;
//    int hashsize = (m & (-m)) * 256 ;
////    printf("hashsize=%d\n",hashsize);
//    char * adjmatrix = (char *) calloc(n*n,1);
////    char * hash = (char *) calloc(hashsize, 1) ;
////    float * v = (float *) malloc(2*n*sizeof(float)) ;
//    for (int i=0 ; i<n ; i++) adjmatrix[i*n+i] = 1 ;
//    for (int i=0 ; i<m ; i++){
//        do{
//            first[i] = drand48() * n ;
//            second[i] = drand48() * n ;
//        } while(adjmatrix[first[i]*n+second[i]]) ;
//        adjmatrix[first[i]*n+second[i]] = adjmatrix[first[i]+n*second[i]] = 1 ;
//        hash[((first[i]*n+second[i])*1103515245) & (hashsize-1)] = 
//                hash[((first[i]+n*second[i])*1103515245) & (hashsize-1)] = 1 ;
//        
//    }
//    testVar(1000);
    omp_set_num_threads(NUM_THREADS);
    d = 2;
    readfile("minnesota");
//    readfile("luxembourg");
//    readfile2("dblpAdj");
//    readfile2("pubmedAdj");
//    readfile2("heliAdj");
//    readfile2("footballAdj");
//    readfile2("stackoverflowAdj");
//    readfile2("powerAdj");
//    readfile2("karate");
//    readfile("dblp");
//    m = m / 16 * 16;
// generateBCSR("pubmedAdj.bcsr");
// generateAdjList("pubmedAdj.graph");
// exit(0);

    //    scrambleEdges();
    //    scrambleCollisions();

    printf("n=%d m=%d hashsize=%d\n", n, m, hashsize);
    for(int i=0 ; i<10 && i<m ; i++)
        printf("Edge %d %4d %4d\n", i, first[i], second[i]);
    for(int i=0 ; i<m ; i++)
        hash[((first[i]*n+second[i])*1103515245) & (hashsize-1)] = 
                hash[((first[i]+n*second[i])*1103515245) & (hashsize-1)] = 1 ;

    srand48(11);
    randominit() ;
//    readcoord("luxembourg2.num");

    firstIterApprox(1); 
    printf("sigmaFromHist: %f\n", sigmaFromHist());
    system("date");
    firstIterApprox(10000); 
    sigma = sigmaFromHist();
//    sigma = .74;
    printHist();
    printf("sigmaFromHist: %f\n", sigma);
    system("date");
    FILE * coordf2 = fopen("coord-before", "w");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < d; j++)
            fprintf(coordf2, "%f ", v[i + n * j]);
        fprintf(coordf2, "\n");
    }
    fclose(coordf2);
    if(d==2)
        grid2DIterApprox(1000);
    system("date");
    printf("sigmaFromHist(wrong): %f\n", sigmaFromHist());
    sampleDistancesToHistom(1000000);
    printf("sigmaFromHist(resp.): %f\n", sigmaFromHist());
    printf("cost: %f Bit\n", costFromHist());
    printHist();
    FILE * of = fopen("OUTPUT", "w");
    if (d == 2)
        for (int i = 0; i < m; i++)
            fprintf(of, "%f %f\n%f %f\n\n", v[first[i]], v[first[i] + n], v[second[i]], v[second[i] + n]);
    if (d == 3)
        for (int i = 0; i < m; i++)
            fprintf(of, "%f %f %f\n%f %f %f\n\n", v[first[i]], v[first[i]+n], v[first[i]+n*2], v[second[i]], v[second[i]+n], v[second[i]+2*n]);
    fclose(of);
    FILE * coordf = fopen("coord", "w");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < d; j++)
            fprintf(coordf, "%f ", v[i + n * j]);
        fprintf(coordf, "\n");
    }
    fclose(coordf);

}